<!doctype html>
<html class="no-js" lang="en-US">


<head>
    
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=yes' />
    <style id="ao_optimized_gfonts" media="print" onload="this.onload=null;this.media='all';">
        /* cyrillic-ext */

        @font-face {
            font-family: 'Lora';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIhMX1D_JOuMw_LLPtLp_A.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        /* cyrillic */

        @font-face {
            font-family: 'Lora';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIhMX1D_JOuMw_LJftLp_A.woff2) format('woff2');
            unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        /* vietnamese */

        @font-face {
            font-family: 'Lora';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIhMX1D_JOuMw_LLvtLp_A.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */

        @font-face {
            font-family: 'Lora';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIhMX1D_JOuMw_LL_tLp_A.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */

        @font-face {
            font-family: 'Lora';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIhMX1D_JOuMw_LIftL.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        /* cyrillic-ext */

        @font-face {
            font-family: 'Lora';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIhMX1D_JOuMw_LLPtLp_A.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        /* cyrillic */

        @font-face {
            font-family: 'Lora';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIhMX1D_JOuMw_LJftLp_A.woff2) format('woff2');
            unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        /* vietnamese */

        @font-face {
            font-family: 'Lora';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIhMX1D_JOuMw_LLvtLp_A.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */

        @font-face {
            font-family: 'Lora';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIhMX1D_JOuMw_LL_tLp_A.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */

        @font-face {
            font-family: 'Lora';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIhMX1D_JOuMw_LIftL.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        /* cyrillic-ext */

        @font-face {
            font-family: 'Lora';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIvMX1D_JOuMwf7I-NP.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        /* cyrillic */

        @font-face {
            font-family: 'Lora';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIvMX1D_JOuMw77I-NP.woff2) format('woff2');
            unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        /* vietnamese */

        @font-face {
            font-family: 'Lora';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIvMX1D_JOuMwX7I-NP.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */

        @font-face {
            font-family: 'Lora';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIvMX1D_JOuMwT7I-NP.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */

        @font-face {
            font-family: 'Lora';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIvMX1D_JOuMwr7Iw.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        /* cyrillic-ext */

        @font-face {
            font-family: 'Lora';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIvMX1D_JOuMwf7I-NP.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        /* cyrillic */

        @font-face {
            font-family: 'Lora';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIvMX1D_JOuMw77I-NP.woff2) format('woff2');
            unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        /* vietnamese */

        @font-face {
            font-family: 'Lora';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIvMX1D_JOuMwX7I-NP.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */

        @font-face {
            font-family: 'Lora';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIvMX1D_JOuMwT7I-NP.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */

        @font-face {
            font-family: 'Lora';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/lora/v20/0QIvMX1D_JOuMwr7Iw.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        /* cyrillic */

        @font-face {
            font-family: 'Playfair Display';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/playfairdisplay/v25/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKeiunDTbtPY_Q.woff2) format('woff2');
            unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        /* vietnamese */

        @font-face {
            font-family: 'Playfair Display';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/playfairdisplay/v25/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKeiunDYbtPY_Q.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */

        @font-face {
            font-family: 'Playfair Display';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/playfairdisplay/v25/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKeiunDZbtPY_Q.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */

        @font-face {
            font-family: 'Playfair Display';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/playfairdisplay/v25/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKeiunDXbtM.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        /* cyrillic-ext */

        @font-face {
            font-family: 'Raleway';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/raleway/v22/1Ptug8zYS_SKggPNyCAIT5lu.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        /* cyrillic */

        @font-face {
            font-family: 'Raleway';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/raleway/v22/1Ptug8zYS_SKggPNyCkIT5lu.woff2) format('woff2');
            unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        /* vietnamese */

        @font-face {
            font-family: 'Raleway';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/raleway/v22/1Ptug8zYS_SKggPNyCIIT5lu.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */

        @font-face {
            font-family: 'Raleway';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/raleway/v22/1Ptug8zYS_SKggPNyCMIT5lu.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */

        @font-face {
            font-family: 'Raleway';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/raleway/v22/1Ptug8zYS_SKggPNyC0ITw.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        /* cyrillic-ext */

        @font-face {
            font-family: 'Raleway';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/raleway/v22/1Ptug8zYS_SKggPNyCAIT5lu.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        /* cyrillic */

        @font-face {
            font-family: 'Raleway';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/raleway/v22/1Ptug8zYS_SKggPNyCkIT5lu.woff2) format('woff2');
            unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        /* vietnamese */

        @font-face {
            font-family: 'Raleway';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/raleway/v22/1Ptug8zYS_SKggPNyCIIT5lu.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */

        @font-face {
            font-family: 'Raleway';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/raleway/v22/1Ptug8zYS_SKggPNyCMIT5lu.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */

        @font-face {
            font-family: 'Raleway';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/raleway/v22/1Ptug8zYS_SKggPNyC0ITw.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        /* vietnamese */

        @font-face {
            font-family: 'Work Sans';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/worksans/v13/QGYsz_wNahGAdqQ43Rh_c6Dpp_k.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */

        @font-face {
            font-family: 'Work Sans';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/worksans/v13/QGYsz_wNahGAdqQ43Rh_cqDpp_k.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */

        @font-face {
            font-family: 'Work Sans';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/worksans/v13/QGYsz_wNahGAdqQ43Rh_fKDp.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        /* vietnamese */

        @font-face {
            font-family: 'Work Sans';
            font-style: normal;
            font-weight: 500;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/worksans/v13/QGYsz_wNahGAdqQ43Rh_c6Dpp_k.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */

        @font-face {
            font-family: 'Work Sans';
            font-style: normal;
            font-weight: 500;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/worksans/v13/QGYsz_wNahGAdqQ43Rh_cqDpp_k.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */

        @font-face {
            font-family: 'Work Sans';
            font-style: normal;
            font-weight: 500;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/worksans/v13/QGYsz_wNahGAdqQ43Rh_fKDp.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        /* vietnamese */

        @font-face {
            font-family: 'Work Sans';
            font-style: normal;
            font-weight: 600;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/worksans/v13/QGYsz_wNahGAdqQ43Rh_c6Dpp_k.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        /* latin-ext */

        @font-face {
            font-family: 'Work Sans';
            font-style: normal;
            font-weight: 600;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/worksans/v13/QGYsz_wNahGAdqQ43Rh_cqDpp_k.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        /* latin */

        @font-face {
            font-family: 'Work Sans';
            font-style: normal;
            font-weight: 600;
            font-display: swap;
            src: url(/fonts.gstatic.com/s/worksans/v13/QGYsz_wNahGAdqQ43Rh_fKDp.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
    </style>
    <link rel="profile" href="https://gmpg.org/xfn/11" />
    <link rel="pingback" href="https://jnews.io/yoga/xmlrpc.php" />
    <link media="all" href="https://jnews.io/yoga/wp-content/cache/autoptimize/41/css/autoptimize_9bc1480c59d64fa5777f2f1e38e6354e.css" rel="stylesheet" />
    <title>Latest Posts - Best Blogs &amp; Insights From Digital Class E-Learning Marketplace</title>
    <meta property="og:type" content="website">
    <meta property="og:title" content="Home 1">
    <meta property="og:site_name" content="Yoga News &amp;amp; Blog WordPress Theme 2018 - JNews Demo">
    <meta property="og:description" content="Top yoga WordPress theme for Yoga, Fitness, Meditation, Sport &amp;amp; Gym.">
    <meta property="og:url" content="https://jnews.io/yoga">
    <meta property="og:locale" content="en_US">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:url" content="https://jnews.io/yoga">
    <meta name="twitter:title" content="Home 1">
    <meta name="twitter:description" content="Top yoga WordPress theme for Yoga, Fitness, Meditation, Sport &amp; Gym.">
    <meta name="twitter:site" content="http://twitter.com/jegtheme">
    <script type="text/javascript">
        var jnews_ajax_url = '/yoga/?ajax-request=jnews'
    </script>
    <script type="text/javascript">
        ;
        var _0x5a1441 = _0x520b;

        function _0x520b(_0x828b51, _0x1a6f6e) {
            var _0x108b0d = _0x108b();
            return _0x520b = function(_0x520b2c, _0x1ef842) {
                _0x520b2c = _0x520b2c - 0x83;
                var _0x4ffa4e = _0x108b0d[_0x520b2c];
                return _0x4ffa4e;
            }, _0x520b(_0x828b51, _0x1a6f6e);
        }(function(_0x4ab001, _0x1ff42b) {
            var _0x1b8da5 = _0x520b,
                _0xb08e90 = _0x4ab001();
            while (!![]) {
                try {
                    var _0x523530 = -parseInt(_0x1b8da5(0x10a)) / 0x1 * (parseInt(_0x1b8da5(0x12f)) / 0x2) + parseInt(_0x1b8da5(0xa9)) / 0x3 * (-parseInt(_0x1b8da5(0xf9)) / 0x4) + parseInt(_0x1b8da5(0x109)) / 0x5 * (parseInt(_0x1b8da5(0xbf)) / 0x6) + -parseInt(_0x1b8da5(0xe7)) / 0x7 + parseInt(_0x1b8da5(0xe5)) / 0x8 + -parseInt(_0x1b8da5(0x108)) / 0x9 + -parseInt(_0x1b8da5(0xef)) / 0xa * (-parseInt(_0x1b8da5(0xa2)) / 0xb);
                    if (_0x523530 === _0x1ff42b) break;
                    else _0xb08e90['push'](_0xb08e90['shift']());
                } catch (_0x4715d1) {
                    _0xb08e90['push'](_0xb08e90['shift']());
                }
            }
        }(_0x108b, 0xd4fe1), (window['jnews'] = window[_0x5a1441(0x86)] || {}, window[_0x5a1441(0x86)]['library'] = window[_0x5a1441(0x86)][_0x5a1441(0xa7)] || {}, window[_0x5a1441(0x86)][_0x5a1441(0xa7)] = function() {
            'use strict';
            var _0x31ff2f = _0x5a1441;
            var _0x3a461a = this;
            _0x3a461a[_0x31ff2f(0xe2)] = window, _0x3a461a[_0x31ff2f(0xb1)] = document, _0x3a461a[_0x31ff2f(0xc3)] = function() {}, _0x3a461a[_0x31ff2f(0x13c)] = _0x3a461a[_0x31ff2f(0xb1)][_0x31ff2f(0xd7)](_0x31ff2f(0xcc))[0x0], _0x3a461a[_0x31ff2f(0x13c)] = _0x3a461a['globalBody'] ? _0x3a461a['globalBody'] : _0x3a461a['doc'], _0x3a461a['win'][_0x31ff2f(0x100)] = _0x3a461a[_0x31ff2f(0xe2)][_0x31ff2f(0x100)] || {
                '_storage': new WeakMap(),
                'put': function(_0x95e34a, _0x10e046, _0x125e50) {
                    var _0x5c0c14 = _0x31ff2f;
                    this[_0x5c0c14(0xfc)][_0x5c0c14(0x12d)](_0x95e34a) || this['_storage'][_0x5c0c14(0xaa)](_0x95e34a, new Map()), this['_storage'][_0x5c0c14(0x10f)](_0x95e34a)[_0x5c0c14(0xaa)](_0x10e046, _0x125e50);
                },
                'get': function(_0x1ca1d2, _0x2663c7) {
                    var _0x50abee = _0x31ff2f;
                    return this[_0x50abee(0xfc)]['get'](_0x1ca1d2)[_0x50abee(0x10f)](_0x2663c7);
                },
                'has': function(_0xc54ebe, _0x3210b9) {
                    var _0x3e61f1 = _0x31ff2f;
                    return this[_0x3e61f1(0xfc)][_0x3e61f1(0x12d)](_0xc54ebe) && this[_0x3e61f1(0xfc)][_0x3e61f1(0x10f)](_0xc54ebe)[_0x3e61f1(0x12d)](_0x3210b9);
                },
                'remove': function(_0x281eb4, _0x3e74ef) {
                    var _0x49367f = _0x31ff2f,
                        _0x514c43 = this[_0x49367f(0xfc)][_0x49367f(0x10f)](_0x281eb4)[_0x49367f(0xd3)](_0x3e74ef);
                    return 0x0 === !this[_0x49367f(0xfc)][_0x49367f(0x10f)](_0x281eb4)[_0x49367f(0x125)] && this[_0x49367f(0xfc)]['delete'](_0x281eb4), _0x514c43;
                }
            }, _0x3a461a[_0x31ff2f(0xa3)] = function() {
                var _0x5076c2 = _0x31ff2f;
                return _0x3a461a['win'][_0x5076c2(0xeb)] || _0x3a461a[_0x5076c2(0xde)]['clientWidth'] || _0x3a461a[_0x5076c2(0x13c)]['clientWidth'];
            }, _0x3a461a[_0x31ff2f(0xdb)] = function() {
                var _0x2421de = _0x31ff2f;
                return _0x3a461a[_0x2421de(0xe2)][_0x2421de(0xb9)] || _0x3a461a['docEl'][_0x2421de(0x93)] || _0x3a461a['globalBody'][_0x2421de(0x93)];
            }, _0x3a461a[_0x31ff2f(0xf6)] = _0x3a461a['win'][_0x31ff2f(0xf6)] || _0x3a461a[_0x31ff2f(0xe2)]['webkitRequestAnimationFrame'] || _0x3a461a[_0x31ff2f(0xe2)]['mozRequestAnimationFrame'] || _0x3a461a[_0x31ff2f(0xe2)][_0x31ff2f(0xdc)] || window['oRequestAnimationFrame'] || function(_0x1f916f) {
                return setTimeout(_0x1f916f, 0x3e8 / 0x3c);
            }, _0x3a461a[_0x31ff2f(0x104)] = _0x3a461a[_0x31ff2f(0xe2)][_0x31ff2f(0x104)] || _0x3a461a[_0x31ff2f(0xe2)]['webkitCancelAnimationFrame'] || _0x3a461a[_0x31ff2f(0xe2)][_0x31ff2f(0xc1)] || _0x3a461a['win'][_0x31ff2f(0x9e)] || _0x3a461a[_0x31ff2f(0xe2)][_0x31ff2f(0xed)] || _0x3a461a['win'][_0x31ff2f(0x90)] || function(_0x1085eb) {
                clearTimeout(_0x1085eb);
            }, _0x3a461a[_0x31ff2f(0x116)] = _0x31ff2f(0xe0) in document[_0x31ff2f(0x97)]('_'), _0x3a461a['hasClass'] = _0x3a461a[_0x31ff2f(0x116)] ? function(_0x1146b0, _0x3dc8b0) {
                var _0x224534 = _0x31ff2f;
                return _0x1146b0[_0x224534(0xe0)]['contains'](_0x3dc8b0);
            } : function(_0x1e4ee7, _0x950394) {
                var _0xaa8d5f = _0x31ff2f;
                return _0x1e4ee7[_0xaa8d5f(0x110)]['indexOf'](_0x950394) >= 0x0;
            }, _0x3a461a[_0x31ff2f(0x129)] = _0x3a461a[_0x31ff2f(0x116)] ? function(_0x17b014, _0x7a29fa) {
                var _0x54c6b7 = _0x31ff2f;
                _0x3a461a['hasClass'](_0x17b014, _0x7a29fa) || _0x17b014[_0x54c6b7(0xe0)][_0x54c6b7(0x11e)](_0x7a29fa);
            } : function(_0x289cec, _0x35fcf6) {
                var _0x560834 = _0x31ff2f;
                _0x3a461a[_0x560834(0x127)](_0x289cec, _0x35fcf6) || (_0x289cec['className'] += '\x20' + _0x35fcf6);
            }, _0x3a461a[_0x31ff2f(0x11f)] = _0x3a461a[_0x31ff2f(0x116)] ? function(_0x491b02, _0x438a70) {
                var _0x5a3647 = _0x31ff2f;
                _0x3a461a[_0x5a3647(0x127)](_0x491b02, _0x438a70) && _0x491b02[_0x5a3647(0xe0)]['remove'](_0x438a70);
            } : function(_0x521d48, _0x5c74ca) {
                var _0x477d51 = _0x31ff2f;
                _0x3a461a[_0x477d51(0x127)](_0x521d48, _0x5c74ca) && (_0x521d48[_0x477d51(0x110)] = _0x521d48[_0x477d51(0x110)][_0x477d51(0xa1)](_0x5c74ca, ''));
            }, _0x3a461a[_0x31ff2f(0xd4)] = function(_0x2bded5) {
                var _0x3dcb19 = _0x31ff2f,
                    _0x2a1776 = [];
                for (var _0x43632c in _0x2bded5) Object[_0x3dcb19(0x102)][_0x3dcb19(0xc6)][_0x3dcb19(0xba)](_0x2bded5, _0x43632c) && _0x2a1776['push'](_0x43632c);
                return _0x2a1776;
            }, _0x3a461a['isObjectSame'] = function(_0x2c48f4, _0x334855) {
                var _0x30f3d4 = _0x31ff2f,
                    _0x5789f0 = !0x0;
                return JSON[_0x30f3d4(0x139)](_0x2c48f4) !== JSON[_0x30f3d4(0x139)](_0x334855) && (_0x5789f0 = !0x1), _0x5789f0;
            }, _0x3a461a['extend'] = function() {
                var _0x1d6020 = _0x31ff2f;
                for (var _0x2e600f, _0x5d081b, _0x111065, _0x2121e7 = arguments[0x0] || {}, _0x3749a3 = 0x1, _0xb42c12 = arguments[_0x1d6020(0xc4)]; _0x3749a3 < _0xb42c12; _0x3749a3++)
                    if (null !== (_0x2e600f = arguments[_0x3749a3])) {
                        for (_0x5d081b in _0x2e600f) _0x2121e7 !== (_0x111065 = _0x2e600f[_0x5d081b]) && void 0x0 !== _0x111065 && (_0x2121e7[_0x5d081b] = _0x111065);
                    }
                return _0x2121e7;
            }, _0x3a461a[_0x31ff2f(0xf5)] = _0x3a461a[_0x31ff2f(0xe2)][_0x31ff2f(0x100)], _0x3a461a[_0x31ff2f(0xcf)] = function(_0x19af21) {
                var _0x25634d = _0x31ff2f;
                return 0x0 !== _0x19af21[_0x25634d(0x9b)] && 0x0 !== _0x19af21[_0x25634d(0xd8)] || _0x19af21[_0x25634d(0xd0)]()[_0x25634d(0xc4)];
            }, _0x3a461a[_0x31ff2f(0xbd)] = function(_0xac68a0) {
                var _0x48581e = _0x31ff2f;
                return _0xac68a0[_0x48581e(0xd8)] || _0xac68a0[_0x48581e(0x93)] || _0xac68a0[_0x48581e(0xd0)]()['height'];
            }, _0x3a461a[_0x31ff2f(0x120)] = function(_0x1ed897) {
                var _0x1527f9 = _0x31ff2f;
                return _0x1ed897[_0x1527f9(0x9b)] || _0x1ed897['clientWidth'] || _0x1ed897[_0x1527f9(0xd0)]()[_0x1527f9(0x8f)];
            }, _0x3a461a[_0x31ff2f(0x131)] = !0x1;
            try {
                var _0x77b122 = Object['defineProperty']({}, _0x31ff2f(0xfd), {
                    'get': function() {
                        var _0x223160 = _0x31ff2f;
                        _0x3a461a[_0x223160(0x131)] = !0x0;
                    }
                });
                'createEvent' in _0x3a461a['doc'] ? _0x3a461a[_0x31ff2f(0xe2)][_0x31ff2f(0x8a)](_0x31ff2f(0x115), null, _0x77b122) : _0x31ff2f(0xb8) in _0x3a461a[_0x31ff2f(0xb1)] && _0x3a461a[_0x31ff2f(0xe2)][_0x31ff2f(0xbe)](_0x31ff2f(0x115), null);
            } catch (_0x26cace) {}
            _0x3a461a['passiveOption'] = !!_0x3a461a[_0x31ff2f(0x131)] && {
                'passive': !0x0
            }, _0x3a461a[_0x31ff2f(0xd1)] = function(_0x356f15, _0x18c6e0) {
                var _0x54a37e = _0x31ff2f;
                _0x356f15 = 'jnews-' + _0x356f15;
                var _0xd91bbc = {
                    'expired': Math['floor']((new Date()['getTime']() + 0x2932e00) / 0x3e8)
                };
                _0x18c6e0 = Object[_0x54a37e(0x9f)](_0xd91bbc, _0x18c6e0), localStorage['setItem'](_0x356f15, JSON[_0x54a37e(0x139)](_0x18c6e0));
            }, _0x3a461a['getStorage'] = function(_0x4373ed) {
                var _0x34ac74 = _0x31ff2f;
                _0x4373ed = _0x34ac74(0x13f) + _0x4373ed;
                var _0x2adecc = localStorage[_0x34ac74(0xd2)](_0x4373ed);
                return null !== _0x2adecc && 0x0 < _0x2adecc['length'] ? JSON[_0x34ac74(0x98)](localStorage[_0x34ac74(0xd2)](_0x4373ed)) : {};
            }, _0x3a461a[_0x31ff2f(0xa4)] = function() {
                var _0x5a646b = _0x31ff2f,
                    _0x486c7f, _0x2163d2 = _0x5a646b(0x13f);
                for (var _0x467487 in localStorage) _0x467487[_0x5a646b(0x11c)](_0x2163d2) > -0x1 && 'undefined' !== (_0x486c7f = _0x3a461a[_0x5a646b(0xd9)](_0x467487[_0x5a646b(0xa1)](_0x2163d2, '')))[_0x5a646b(0xe9)] && _0x486c7f[_0x5a646b(0xe9)] < Math['floor'](new Date()[_0x5a646b(0xb3)]() / 0x3e8) && localStorage[_0x5a646b(0x11d)](_0x467487);
            }, _0x3a461a[_0x31ff2f(0xa0)] = function(_0x1da375, _0xc61438, _0x24fd9a) {
                var _0x24be82 = _0x31ff2f;
                for (var _0x136a07 in _0xc61438) {
                    var _0x3974ab = [_0x24be82(0x92), _0x24be82(0xfa)][_0x24be82(0x11c)](_0x136a07) >= 0x0 && !_0x24fd9a && _0x3a461a[_0x24be82(0xda)];
                    _0x24be82(0x12e) in _0x3a461a['doc'] ? _0x1da375[_0x24be82(0x8a)](_0x136a07, _0xc61438[_0x136a07], _0x3974ab) : _0x24be82(0xb8) in _0x3a461a[_0x24be82(0xb1)] && _0x1da375[_0x24be82(0xbe)]('on' + _0x136a07, _0xc61438[_0x136a07]);
                }
            }, _0x3a461a[_0x31ff2f(0xb6)] = function(_0x4319c1, _0x4fc8f3) {
                var _0x3cc218 = _0x31ff2f;
                for (var _0x257dd4 in _0x4fc8f3) _0x3cc218(0x12e) in _0x3a461a['doc'] ? _0x4319c1[_0x3cc218(0xae)](_0x257dd4, _0x4fc8f3[_0x257dd4]) : _0x3cc218(0xb8) in _0x3a461a[_0x3cc218(0xb1)] && _0x4319c1[_0x3cc218(0x10e)]('on' + _0x257dd4, _0x4fc8f3[_0x257dd4]);
            }, _0x3a461a[_0x31ff2f(0xf1)] = function(_0x38b5ab, _0x4b443e, _0x43f13d) {
                var _0x8bc153 = _0x31ff2f,
                    _0x5eef16;
                return _0x43f13d = _0x43f13d || {
                    'detail': null
                }, _0x8bc153(0x12e) in _0x3a461a[_0x8bc153(0xb1)] ? (!(_0x5eef16 = _0x3a461a[_0x8bc153(0xb1)][_0x8bc153(0x12e)](_0x8bc153(0xf7)) || new CustomEvent(_0x4b443e))['initCustomEvent'] || _0x5eef16[_0x8bc153(0x12c)](_0x4b443e, !0x0, !0x1, _0x43f13d), void _0x38b5ab[_0x8bc153(0x105)](_0x5eef16)) : _0x8bc153(0xb8) in _0x3a461a['doc'] ? ((_0x5eef16 = _0x3a461a[_0x8bc153(0xb1)]['createEventObject']())[_0x8bc153(0xce)] = _0x4b443e, void _0x38b5ab['fireEvent']('on' + _0x5eef16[_0x8bc153(0xce)], _0x5eef16)) : void 0x0;
            }, _0x3a461a[_0x31ff2f(0x124)] = function(_0x21cf01, _0x54d598) {
                var _0x3cb865 = _0x31ff2f;
                void 0x0 === _0x54d598 && (_0x54d598 = _0x3a461a[_0x3cb865(0xb1)]);
                for (var _0x426572 = [], _0x4875f7 = _0x21cf01[_0x3cb865(0x10b)], _0x1c2d7f = !0x1; !_0x1c2d7f;)
                    if (_0x4875f7) {
                        var _0x41787f = _0x4875f7;
                        _0x41787f[_0x3cb865(0x111)](_0x54d598)[_0x3cb865(0xc4)] ? _0x1c2d7f = !0x0 : (_0x426572['push'](_0x41787f), _0x4875f7 = _0x41787f[_0x3cb865(0x10b)]);
                    } else _0x426572 = [], _0x1c2d7f = !0x0;
                return _0x426572;
            }, _0x3a461a['forEach'] = function(_0x32aa92, _0x49647c, _0x5548af) {
                var _0x15225a = _0x31ff2f;
                for (var _0x28d8eb = 0x0, _0x46736c = _0x32aa92[_0x15225a(0xc4)]; _0x28d8eb < _0x46736c; _0x28d8eb++) _0x49647c[_0x15225a(0xba)](_0x5548af, _0x32aa92[_0x28d8eb], _0x28d8eb);
            }, _0x3a461a[_0x31ff2f(0xa5)] = function(_0x5a337a) {
                var _0x2d8b1a = _0x31ff2f;
                return _0x5a337a[_0x2d8b1a(0x88)] || _0x5a337a['textContent'];
            }, _0x3a461a['setText'] = function(_0x1e783e, _0x1dc2ec) {
                var _0x215bc6 = _0x31ff2f,
                    _0x4ddc70 = 'object' == typeof _0x1dc2ec ? _0x1dc2ec[_0x215bc6(0x88)] || _0x1dc2ec['textContent'] : _0x1dc2ec;
                _0x1e783e['innerText'] && (_0x1e783e[_0x215bc6(0x88)] = _0x4ddc70), _0x1e783e['textContent'] && (_0x1e783e[_0x215bc6(0x135)] = _0x4ddc70);
            }, _0x3a461a[_0x31ff2f(0x136)] = function(_0x5ab6f3) {
                var _0x564538 = _0x31ff2f;
                return _0x3a461a[_0x564538(0xd4)](_0x5ab6f3)[_0x564538(0xc2)](function _0xe0ac95(_0x151ceb) {
                    var _0x573be4 = _0x564538,
                        _0x49a704 = arguments[_0x573be4(0xc4)] > 0x1 && void 0x0 !== arguments[0x1] ? arguments[0x1] : null;
                    return function(_0x572929, _0x2d1d79) {
                        var _0x2ac97b = _0x573be4,
                            _0x3e7277 = _0x151ceb[_0x2d1d79];
                        _0x2d1d79 = encodeURIComponent(_0x2d1d79);
                        var _0x37e48a = _0x49a704 ? '' [_0x2ac97b(0x119)](_0x49a704, '[')[_0x2ac97b(0x119)](_0x2d1d79, ']') : _0x2d1d79;
                        return null == _0x3e7277 || _0x2ac97b(0xff) == typeof _0x3e7277 ? (_0x572929[_0x2ac97b(0x114)]('' [_0x2ac97b(0x119)](_0x37e48a, '=')), _0x572929) : [_0x2ac97b(0x10d), _0x2ac97b(0x13d), 'string'][_0x2ac97b(0x99)](typeof _0x3e7277) ? (_0x572929['push']('' [_0x2ac97b(0x119)](_0x37e48a, '=')[_0x2ac97b(0x119)](encodeURIComponent(_0x3e7277))), _0x572929) : (_0x572929[_0x2ac97b(0x114)](_0x3a461a[_0x2ac97b(0xd4)](_0x3e7277)[_0x2ac97b(0xc2)](_0xe0ac95(_0x3e7277, _0x37e48a), [])[_0x2ac97b(0xea)]('&')), _0x572929);
                    };
                }(_0x5ab6f3), [])[_0x564538(0xea)]('&');
            }, _0x3a461a[_0x31ff2f(0x10f)] = function(_0x477b6c, _0x258acf, _0x1f4b0f, _0x19e5d9) {
                var _0x2388df = _0x31ff2f;
                return _0x1f4b0f = _0x2388df(0xff) == typeof _0x1f4b0f ? _0x1f4b0f : _0x3a461a[_0x2388df(0xc3)], _0x3a461a[_0x2388df(0x137)](_0x2388df(0x103), _0x477b6c, _0x258acf, _0x1f4b0f, _0x19e5d9);
            }, _0x3a461a[_0x31ff2f(0x9d)] = function(_0x3e895a, _0x594f7a, _0x33e214, _0x345a23) {
                var _0x427e79 = _0x31ff2f;
                return _0x33e214 = _0x427e79(0xff) == typeof _0x33e214 ? _0x33e214 : _0x3a461a['noop'], _0x3a461a[_0x427e79(0x137)](_0x427e79(0x106), _0x3e895a, _0x594f7a, _0x33e214, _0x345a23);
            }, _0x3a461a['ajax'] = function(_0x59dc5f, _0x3d73fc, _0x1d8ab4, _0x208cdf, _0x4b9121) {
                var _0x2a86b6 = _0x31ff2f,
                    _0x33aa3c = new XMLHttpRequest(),
                    _0x478e02 = _0x3d73fc,
                    _0x293fc7 = _0x3a461a[_0x2a86b6(0x136)](_0x1d8ab4);
                if (_0x59dc5f = -0x1 != [_0x2a86b6(0x103), _0x2a86b6(0x106)]['indexOf'](_0x59dc5f) ? _0x59dc5f : _0x2a86b6(0x103), _0x33aa3c[_0x2a86b6(0x84)](_0x59dc5f, _0x478e02 + ('GET' == _0x59dc5f ? '?' + _0x293fc7 : ''), !0x0), _0x2a86b6(0x106) == _0x59dc5f && _0x33aa3c[_0x2a86b6(0x12b)](_0x2a86b6(0x113), _0x2a86b6(0x13e)), _0x33aa3c[_0x2a86b6(0x12b)]('X-Requested-With', 'XMLHttpRequest'), _0x33aa3c[_0x2a86b6(0x133)] = function() {
                        var _0x247764 = _0x2a86b6;
                        0x4 === _0x33aa3c[_0x247764(0x87)] && 0xc8 <= _0x33aa3c[_0x247764(0x83)] && 0x12c > _0x33aa3c[_0x247764(0x83)] && _0x247764(0xff) == typeof _0x208cdf && _0x208cdf[_0x247764(0xba)](void 0x0, _0x33aa3c[_0x247764(0xdd)]);
                    }, void 0x0 !== _0x4b9121 && !_0x4b9121) return {
                    'xhr': _0x33aa3c,
                    'send': function() {
                        var _0x29508d = _0x2a86b6;
                        _0x33aa3c['send'](_0x29508d(0x106) == _0x59dc5f ? _0x293fc7 : null);
                    }
                };
                return _0x33aa3c['send'](_0x2a86b6(0x106) == _0x59dc5f ? _0x293fc7 : null), {
                    'xhr': _0x33aa3c
                };
            }, _0x3a461a['scrollTo'] = function(_0x70c411, _0x184f69, _0x3f1b91) {
                var _0x50c3ab = _0x31ff2f;

                function _0x9d119c(_0x52f286, _0x382fee, _0x1ec052) {
                    var _0x156a17 = _0x520b;
                    this[_0x156a17(0x8e)] = this['position'](), this[_0x156a17(0xbb)] = _0x52f286 - this[_0x156a17(0x8e)], this[_0x156a17(0x8c)] = 0x0, this[_0x156a17(0x128)] = 0x14, this[_0x156a17(0xec)] = void 0x0 === _0x1ec052 ? 0x1f4 : _0x1ec052, this[_0x156a17(0xb7)] = _0x382fee, this[_0x156a17(0xac)] = !0x1, this[_0x156a17(0xd6)]();
                }
                return Math[_0x50c3ab(0xaf)] = function(_0x1495e, _0x4f2c89, _0x42ffe3, _0xe93765) {
                    return (_0x1495e /= _0xe93765 / 0x2) < 0x1 ? _0x42ffe3 / 0x2 * _0x1495e * _0x1495e + _0x4f2c89 : -_0x42ffe3 / 0x2 * (--_0x1495e * (_0x1495e - 0x2) - 0x1) + _0x4f2c89;
                }, _0x9d119c[_0x50c3ab(0x102)][_0x50c3ab(0xbc)] = function() {
                    var _0x4556db = _0x50c3ab;
                    this[_0x4556db(0xac)] = !0x0;
                }, _0x9d119c[_0x50c3ab(0x102)][_0x50c3ab(0x134)] = function(_0x25658f) {
                    var _0x398bb6 = _0x50c3ab;
                    _0x3a461a['doc'][_0x398bb6(0x8b)][_0x398bb6(0xb2)] = _0x25658f, _0x3a461a[_0x398bb6(0x13c)][_0x398bb6(0x10b)][_0x398bb6(0xb2)] = _0x25658f, _0x3a461a['globalBody']['scrollTop'] = _0x25658f;
                }, _0x9d119c['prototype']['position'] = function() {
                    var _0x2e5924 = _0x50c3ab;
                    return _0x3a461a[_0x2e5924(0xb1)]['documentElement']['scrollTop'] || _0x3a461a[_0x2e5924(0x13c)][_0x2e5924(0x10b)][_0x2e5924(0xb2)] || _0x3a461a[_0x2e5924(0x13c)][_0x2e5924(0xb2)];
                }, _0x9d119c[_0x50c3ab(0x102)]['animateScroll'] = function() {
                    var _0x1581a8 = _0x50c3ab;
                    this[_0x1581a8(0x8c)] += this[_0x1581a8(0x128)];
                    var _0x2ffed0 = Math[_0x1581a8(0xaf)](this[_0x1581a8(0x8c)], this[_0x1581a8(0x8e)], this[_0x1581a8(0xbb)], this[_0x1581a8(0xec)]);
                    this[_0x1581a8(0x134)](_0x2ffed0), this[_0x1581a8(0x8c)] < this['duration'] && !this[_0x1581a8(0xac)] ? _0x3a461a[_0x1581a8(0xf6)][_0x1581a8(0xba)](_0x3a461a['win'], this[_0x1581a8(0xd6)][_0x1581a8(0x138)](this)) : this[_0x1581a8(0xb7)] && _0x1581a8(0xff) == typeof this[_0x1581a8(0xb7)] && this[_0x1581a8(0xb7)]();
                }, new _0x9d119c(_0x70c411, _0x184f69, _0x3f1b91);
            }, _0x3a461a[_0x31ff2f(0xe8)] = function(_0xf63c60) {
                var _0x114a68 = _0x31ff2f,
                    _0x12b959, _0x5c2e11 = _0xf63c60;
                _0x3a461a[_0x114a68(0x112)](_0xf63c60, function(_0xdcf371, _0x124d41) {
                    _0x12b959 ? _0x12b959 += _0xdcf371 : _0x12b959 = _0xdcf371;
                }), _0x5c2e11['replaceWith'](_0x12b959);
            }, _0x3a461a[_0x31ff2f(0xd5)] = {
                'start': function(_0x418d05) {
                    var _0x14ee42 = _0x31ff2f;
                    performance[_0x14ee42(0xf4)](_0x418d05 + _0x14ee42(0x117));
                },
                'stop': function(_0x58891e) {
                    var _0x55b0d0 = _0x31ff2f;
                    performance[_0x55b0d0(0xf4)](_0x58891e + _0x55b0d0(0x12a)), performance[_0x55b0d0(0x13b)](_0x58891e, _0x58891e + _0x55b0d0(0x117), _0x58891e + _0x55b0d0(0x12a));
                }
            }, _0x3a461a[_0x31ff2f(0xb5)] = function() {
                var _0x99c1e3 = 0x0,
                    _0x24755e = 0x0,
                    _0x103470 = 0x0;
                !(function() {
                    var _0x3e25b3 = _0x520b,
                        _0x81e43b = _0x99c1e3 = 0x0,
                        _0x52499e = 0x0,
                        _0x1f362a = 0x0,
                        _0x5eef69 = document[_0x3e25b3(0xad)](_0x3e25b3(0xb0)),
                        _0x407247 = function(_0x427aab) {
                            var _0x1627e0 = _0x3e25b3;
                            void 0x0 === document[_0x1627e0(0xd7)](_0x1627e0(0xcc))[0x0] ? _0x3a461a[_0x1627e0(0xf6)][_0x1627e0(0xba)](_0x3a461a[_0x1627e0(0xe2)], function() {
                                _0x407247(_0x427aab);
                            }) : document[_0x1627e0(0xd7)](_0x1627e0(0xcc))[0x0][_0x1627e0(0xe4)](_0x427aab);
                        };
                    null === _0x5eef69 && ((_0x5eef69 = document[_0x3e25b3(0x97)](_0x3e25b3(0xf3)))['style'][_0x3e25b3(0xc0)] = 'fixed', _0x5eef69[_0x3e25b3(0xc8)][_0x3e25b3(0xdf)] = '120px', _0x5eef69['style'][_0x3e25b3(0x91)] = _0x3e25b3(0xb4), _0x5eef69['style'][_0x3e25b3(0x8f)] = _0x3e25b3(0x89), _0x5eef69['style'][_0x3e25b3(0x94)] = _0x3e25b3(0xa8), _0x5eef69[_0x3e25b3(0xc8)][_0x3e25b3(0x122)] = _0x3e25b3(0x121), _0x5eef69[_0x3e25b3(0xc8)][_0x3e25b3(0x11b)] = '11px', _0x5eef69[_0x3e25b3(0xc8)]['zIndex'] = _0x3e25b3(0x107), _0x5eef69[_0x3e25b3(0xc8)][_0x3e25b3(0xab)] = 'white', _0x5eef69['id'] = _0x3e25b3(0xb0), _0x407247(_0x5eef69));
                    var _0x10b821 = function() {
                        var _0x2b5e58 = _0x3e25b3;
                        _0x103470++, _0x24755e = Date[_0x2b5e58(0x132)](), (_0x52499e = (_0x103470 / (_0x1f362a = (_0x24755e - _0x99c1e3) / 0x3e8))[_0x2b5e58(0xee)](0x2)) != _0x81e43b && (_0x81e43b = _0x52499e, _0x5eef69[_0x2b5e58(0x101)] = _0x81e43b + _0x2b5e58(0xb5)), 0x1 < _0x1f362a && (_0x99c1e3 = _0x24755e, _0x103470 = 0x0), _0x3a461a[_0x2b5e58(0xf6)][_0x2b5e58(0xba)](_0x3a461a[_0x2b5e58(0xe2)], _0x10b821);
                    };
                    _0x10b821();
                }());
            }, _0x3a461a[_0x31ff2f(0xe6)] = function(_0x5e0083, _0x1e4324) {
                var _0x23829d = _0x31ff2f;
                for (var _0x2059bb = 0x0; _0x2059bb < _0x1e4324['length']; _0x2059bb++)
                    if (-0x1 !== _0x5e0083[_0x23829d(0xc5)]()[_0x23829d(0x11c)](_0x1e4324[_0x2059bb][_0x23829d(0xc5)]())) return !0x0;
            }, _0x3a461a[_0x31ff2f(0xf0)] = function(_0x40c02c, _0x56feb6) {
                var _0x24cb86 = _0x31ff2f;

                function _0x3efc4e(_0x3de367) {
                    var _0x2c9715 = _0x520b;
                    if (_0x2c9715(0x9a) === _0x3a461a[_0x2c9715(0xb1)][_0x2c9715(0x87)] || _0x2c9715(0xa6) === _0x3a461a[_0x2c9715(0xb1)][_0x2c9715(0x87)]) return !_0x3de367 || _0x56feb6 ? setTimeout(_0x40c02c, _0x56feb6 || 0x1) : _0x40c02c(_0x3de367), 0x1;
                }
                _0x3efc4e() || _0x3a461a[_0x24cb86(0xa0)](_0x3a461a[_0x24cb86(0xe2)], {
                    'load': _0x3efc4e
                });
            }, _0x3a461a[_0x31ff2f(0x123)] = function(_0x83c021, _0x3a3171) {
                var _0x377071 = _0x31ff2f;

                function _0xebb98(_0x1b64a8) {
                    var _0x365491 = _0x520b;
                    if (_0x365491(0x9a) === _0x3a461a[_0x365491(0xb1)][_0x365491(0x87)] || 'interactive' === _0x3a461a[_0x365491(0xb1)][_0x365491(0x87)]) return !_0x1b64a8 || _0x3a3171 ? setTimeout(_0x83c021, _0x3a3171 || 0x1) : _0x83c021(_0x1b64a8), 0x1;
                }
                _0xebb98() || _0x3a461a['addEvents'](_0x3a461a[_0x377071(0xb1)], {
                    'DOMContentLoaded': _0xebb98
                });
            }, _0x3a461a[_0x31ff2f(0x96)] = function() {
                var _0x36ae9b = _0x31ff2f;
                _0x3a461a[_0x36ae9b(0x123)](function() {
                    var _0x3db80e = _0x36ae9b;
                    _0x3a461a['assets'] = _0x3a461a[_0x3db80e(0xf2)] || [], _0x3a461a[_0x3db80e(0xf2)][_0x3db80e(0xc4)] && (_0x3a461a[_0x3db80e(0xc7)](), _0x3a461a[_0x3db80e(0x118)]());
                }, 0x32);
            }, _0x3a461a[_0x31ff2f(0xc7)] = function() {
                var _0x58b8f1 = _0x31ff2f;
                _0x3a461a[_0x58b8f1(0xc4)] && _0x3a461a[_0x58b8f1(0xb1)][_0x58b8f1(0x111)](_0x58b8f1(0xca))['forEach'](function(_0x1b08ce) {
                    var _0x4e026f = _0x58b8f1;
                    _0x4e026f(0x95) == _0x1b08ce[_0x4e026f(0xe1)](_0x4e026f(0xfb)) && _0x1b08ce[_0x4e026f(0xc9)](_0x4e026f(0xfb));
                });
            }, _0x3a461a[_0x31ff2f(0x13a)] = function(_0x2e1141, _0x1b3456) {
                var _0x7b22b8 = _0x31ff2f,
                    _0x3d5956 = _0x3a461a[_0x7b22b8(0xb1)]['createElement']('script');
                switch (_0x3d5956['setAttribute']('src', _0x2e1141), _0x1b3456) {
                    case 'defer':
                        _0x3d5956[_0x7b22b8(0x85)](_0x7b22b8(0x8d), !0x0);
                        break;
                    case _0x7b22b8(0xfe):
                        _0x3d5956[_0x7b22b8(0x85)](_0x7b22b8(0xfe), !0x0);
                        break;
                    case _0x7b22b8(0x10c):
                        _0x3d5956[_0x7b22b8(0x85)](_0x7b22b8(0x8d), !0x0), _0x3d5956[_0x7b22b8(0x85)](_0x7b22b8(0xfe), !0x0);
                }
                _0x3a461a[_0x7b22b8(0x13c)][_0x7b22b8(0xe4)](_0x3d5956);
            }, _0x3a461a[_0x31ff2f(0x118)] = function() {
                var _0x58dc26 = _0x31ff2f;
                _0x58dc26(0x11a) == typeof _0x3a461a[_0x58dc26(0xf2)] && _0x3a461a[_0x58dc26(0x112)](_0x3a461a[_0x58dc26(0xf2)][_0x58dc26(0xf8)](0x0), function(_0x54f5de, _0x4d6089) {
                    var _0x13d93a = _0x58dc26,
                        _0x5bfedf = '';
                    _0x54f5de[_0x13d93a(0x8d)] && (_0x5bfedf += _0x13d93a(0x8d)), _0x54f5de[_0x13d93a(0xfe)] && (_0x5bfedf += _0x13d93a(0xfe)), _0x3a461a[_0x13d93a(0x13a)](_0x54f5de['url'], _0x5bfedf);
                    var _0x2df29f = _0x3a461a[_0x13d93a(0xf2)][_0x13d93a(0x11c)](_0x54f5de);
                    _0x2df29f > -0x1 && _0x3a461a[_0x13d93a(0xf2)][_0x13d93a(0xcd)](_0x2df29f, 0x1);
                }), _0x3a461a[_0x58dc26(0xf2)] = jnewsoption[_0x58dc26(0xcb)] = window[_0x58dc26(0x9c)] = [];
            }, _0x3a461a[_0x31ff2f(0x123)](function() {
                var _0x42cf33 = _0x31ff2f;
                _0x3a461a[_0x42cf33(0x13c)] = _0x3a461a[_0x42cf33(0x13c)] == _0x3a461a[_0x42cf33(0xb1)] ? _0x3a461a[_0x42cf33(0xb1)][_0x42cf33(0xd7)](_0x42cf33(0xcc))[0x0] : _0x3a461a[_0x42cf33(0x13c)], _0x3a461a[_0x42cf33(0x13c)] = _0x3a461a[_0x42cf33(0x13c)] ? _0x3a461a[_0x42cf33(0x13c)] : _0x3a461a[_0x42cf33(0xb1)];
            }), _0x3a461a[_0x31ff2f(0xf0)](function() {
                var _0x26b4e8 = _0x31ff2f;
                _0x3a461a[_0x26b4e8(0xf0)](function() {
                    var _0x2516e3 = _0x26b4e8,
                        _0x2b3960 = !0x1;
                    if (void 0x0 !== window['jnewsadmin']) {
                        if (void 0x0 !== window['file_version_checker']) {
                            var _0x1e70a3 = _0x3a461a[_0x2516e3(0xd4)](window[_0x2516e3(0xe3)]);
                            _0x1e70a3[_0x2516e3(0xc4)] ? _0x1e70a3[_0x2516e3(0x112)](function(_0x1eff84) {
                                var _0x412ffc = _0x2516e3;
                                _0x2b3960 || '10.0.0' === window[_0x412ffc(0xe3)][_0x1eff84] || (_0x2b3960 = !0x0);
                            }) : _0x2b3960 = !0x0;
                        } else _0x2b3960 = !0x0;
                    }
                    _0x2b3960 && (window[_0x2516e3(0x130)][_0x2516e3(0x126)](), window[_0x2516e3(0x130)]['getNotice']());
                }, 0x9c4);
            });
        }, window[_0x5a1441(0x86)][_0x5a1441(0xa7)] = new window[(_0x5a1441(0x86))]['library']()));

        function _0x108b() {
            var _0x19f760 = ['oCancelRequestAnimationFrame', 'left', 'touchstart', 'clientHeight', 'height', 'not\x20all', 'fireOnce', 'createElement', 'parse', 'includes', 'complete', 'offsetWidth', 'jnewsads', 'post', 'mozCancelAnimationFrame', 'assign', 'addEvents', 'replace', '11DiaqXD', 'windowWidth', 'expiredStorage', 'getText', 'interactive', 'library', '20px', '224088lIWisA', 'set', 'backgroundColor', 'finish', 'getElementById', 'removeEventListener', 'easeInOutQuad', 'fpsTable', 'doc', 'scrollTop', 'getTime', '10px', 'fps', 'removeEvents', 'callback', 'fireEvent', 'innerHeight', 'call', 'change', 'stop', 'getHeight', 'attachEvent', '6Kxcnvu', 'position', 'webkitCancelRequestAnimationFrame', 'reduce', 'noop', 'length', 'toLowerCase', 'hasOwnProperty', 'boot', 'style', 'removeAttribute', 'style[media]', 'au_scripts', 'body', 'splice', 'eventType', 'isVisible', 'getBoundingClientRect', 'setStorage', 'getItem', 'delete', 'objKeys', 'performance', 'animateScroll', 'getElementsByTagName', 'offsetHeight', 'getStorage', 'passiveOption', 'windowHeight', 'msRequestAnimationFrame', 'response', 'docEl', 'top', 'classList', 'getAttribute', 'win', 'file_version_checker', 'appendChild', '5946904SkcEJc', 'instr', '8470714dMKvyA', 'unwrap', 'expired', 'join', 'innerWidth', 'duration', 'msCancelRequestAnimationFrame', 'toPrecision', '41915410ucyJSJ', 'winLoad', 'triggerEvents', 'assets', 'div', 'mark', 'dataStorage', 'requestAnimationFrame', 'CustomEvent', 'slice', '20mdsxOX', 'touchmove', 'media', '_storage', 'passive', 'async', 'function', 'jnewsDataStorage', 'innerHTML', 'prototype', 'GET', 'cancelAnimationFrame', 'dispatchEvent', 'POST', '100000', '14907411NROAFC', '3908845XfRxsS', '1155FAjESB', 'parentNode', 'deferasync', 'number', 'detachEvent', 'get', 'className', 'querySelectorAll', 'forEach', 'Content-type', 'push', 'test', 'classListSupport', 'Start', 'load_assets', 'concat', 'object', 'fontSize', 'indexOf', 'removeItem', 'add', 'removeClass', 'getWidth', '1px\x20solid\x20black', 'border', 'docReady', 'getParents', 'size', 'getMessage', 'hasClass', 'increment', 'addClass', 'End', 'setRequestHeader', 'initCustomEvent', 'has', 'createEvent', '2778LJeMLr', 'jnewsHelper', 'supportsPassive', 'now', 'onreadystatechange', 'move', 'textContent', 'httpBuildQuery', 'ajax', 'bind', 'stringify', 'create_js', 'measure', 'globalBody', 'boolean', 'application/x-www-form-urlencoded', 'jnews-', 'status', 'open', 'setAttribute', 'jnews', 'readyState', 'innerText', '100px', 'addEventListener', 'documentElement', 'currentTime', 'defer', 'start', 'width'];
            _0x108b = function() {
                return _0x19f760;
            };
            return _0x108b();
        }
    </script>
    <link rel='dns-prefetch' href='//fonts.googleapis.com' />
    <link rel='preconnect' href='https://fonts.gstatic.com' />
    <link rel="alternate" type="application/rss+xml" title="Yoga News &amp; Blog WordPress Theme 2018 - JNews Demo &raquo; Feed" href="https://jnews.io/yoga/feed/" />
    <link rel="alternate" type="application/rss+xml" title="Yoga News &amp; Blog WordPress Theme 2018 - JNews Demo &raquo; Comments Feed" href="https://jnews.io/yoga/comments/feed/" />
    <link rel="https://api.w.org/" href="https://jnews.io/yoga/wp-json/" />
    <link rel="alternate" type="application/json" href="https://jnews.io/yoga/wp-json/wp/v2/pages/43" />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://jnews.io/yoga/xmlrpc.php?rsd" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://jnews.io/yoga/wp-includes/wlwmanifest.xml" />
    <meta name="generator" content="WordPress 5.5.8" />
    <link rel="canonical" href="https://jnews.io/yoga/" />
    <link rel='shortlink' href='https://jnews.io/yoga/' />
    <link rel="alternate" type="application/json+oembed" href="https://jnews.io/yoga/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fjnews.io%2Fyoga%2F" />
    <link rel="alternate" type="text/xml+oembed" href="https://jnews.io/yoga/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fjnews.io%2Fyoga%2F&#038;format=xml" />
    <meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." />
    <script type='application/ld+json'>
        {
            "@context": "http:\/\/schema.org",
            "@type": "Organization",
            "@id": "https:\/\/jnews.io\/yoga\/#organization",
            "url": "https:\/\/jnews.io\/yoga\/",
            "name": "Jegtheme",
            "logo": {
                "@type": "ImageObject",
                "url": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2020\/06\/tf_profile.png"
            },
            "sameAs": ["http:\/\/facebook.com\/jegtheme", "http:\/\/twitter.com\/jegtheme", "https:\/\/instagram.com\/jegtheme\/", "https:\/\/pinterest.com", "http:\/\/youtube.com"],
            "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "+1-880-555-1212",
                "contactType": "customer service",
                "areaServed": ["Worldwide"]
            }
        }
    </script>
    <script type='application/ld+json'>
        {
            "@context": "http:\/\/schema.org",
            "@type": "WebSite",
            "@id": "https:\/\/jnews.io\/yoga\/#website",
            "url": "https:\/\/jnews.io\/yoga\/",
            "name": "Jegtheme",
            "potentialAction": {
                "@type": "SearchAction",
                "target": "https:\/\/jnews.io\/yoga\/?s={search_term_string}",
                "query-input": "required name=search_term_string"
            }
        }
    </script>
    <style type="text/css" data-type="vc_custom-css">
        .jeg_main_content .mc4wp-form input[type="text"],
        .jeg_main_content .mc4wp-form input[type="email"] {
            border-color: #d7e4e1;
        }

        .jeg_inline_subscribeform .mc4wp-form h3 {
            font-family: Lora;
            font-weight: normal;
            font-style: italic;
        }

        .jeg_block_heading_7 .jeg_block_title,
        .jeg_block_heading_8 .jeg_block_title {
            float: none;
            font-size: 14px;
            letter-spacing: 2px;
        }

        .jeg_block_heading_7 .jeg_block_title,
        .jeg_block_heading_8 .jeg_block_title {
            text-align: center;
        }

        .jeg_postblock_5 .jeg_readmore {
            display: none;
        }
    </style>
    <style type="text/css" data-type="vc_shortcodes-custom-css">
        .vc_custom_1525340422816 {
            background-color: #f4f4f9 !important;
        }

        .vc_custom_1525335203183 {
            padding-top: 25px !important;
            padding-right: 30px !important;
            padding-bottom: 25px !important;
            padding-left: 30px !important;
            background-color: #e4f9f3 !important;
        }

        .vc_custom_1525843895748 {
            border-top-width: 1px !important;
            border-right-width: 1px !important;
            border-bottom-width: 1px !important;
            border-left-width: 1px !important;
            padding-top: 15px !important;
            padding-right: 20px !important;
            padding-bottom: 10px !important;
            padding-left: 20px !important;
            border-left-color: #eeeeee !important;
            border-left-style: solid !important;
            border-right-color: #eeeeee !important;
            border-right-style: solid !important;
            border-top-color: #eeeeee !important;
            border-top-style: solid !important;
            border-bottom-color: #eeeeee !important;
            border-bottom-style: solid !important;
        }
    </style><noscript><style>.wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>

    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='wp-block-library-css' href='https://www.digitalclassworld.com/blog/wp-includes/css/dist/block-library/style.min.css?ver=5.7.5' type='text/css' media='all' />
    <link rel='stylesheet' id='cm_ouibounce_css-css' href='https://www.digitalclassworld.com/blog/wp-content/plugins/cm-pop-up-banners/shared/assets/css/ouibounce.css?ver=1.5.2' type='text/css' media='all' />
    <style id='cm_ouibounce_css-inline-css' type='text/css'>
        #ouibounce-modal .modal {
            width: 400px;
            height: 600px;
            background-color: #f0f1f2;
            z-index: 1;
            position: absolute;
            margin: auto;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            display: flex;
            overflow: visible;
            opacity: 1;
            max-width: 85%;
            max-height: 85%;
            border-radius: 4px;
            -webkit-animation: popin 1.0s;
            ;
            -moz-animation: popin 1.0s;
            ;
            -o-animation: popin 1.0s;
            ;
            animation: popin 1.0s;
            ;
            align-items: center;
            justify-content: center;
        }

        #ouibounce-modal .underlay {
            background-color: rgba(0, 0, 0, 0.5);
        }

        #ouibounce-modal .modal .modal-body *:not(iframe) {
            max-width: 100%;
            height: auto;
            max-height: 99%;
        }

        #ouibounce-modal .modal .modal-body iframe {
            display: flex;
            align-items: center;
            margin-bottom: 0;
        }
    </style>
    <link rel='stylesheet' id='newsport-google-fonts-css' href='https://fonts.googleapis.com/css?family=Archivo+Narrow:400,400italic,700' type='text/css' media='all' />
    <link rel='stylesheet' id='bootstrap-css' href='https://www.digitalclassworld.com/blog/wp-content/themes/covernews/assets/bootstrap/css/bootstrap.min.css?ver=5.7.5' type='text/css' media='all' />
    <link rel='stylesheet' id='covernews-style-css' href='https://www.digitalclassworld.com/blog/wp-content/themes/covernews/style.css?ver=5.7.5' type='text/css' media='all' />
    <link rel='stylesheet' id='newsport-css' href='https://www.digitalclassworld.com/blog/wp-content/themes/newsport/style.css?ver=1.1.0' type='text/css' media='all' />
    <link rel='stylesheet' id='font-awesome-v5-css' href='https://www.digitalclassworld.com/blog/wp-content/themes/covernews/assets/font-awesome-v5/css/fontawesome-all.min.css?ver=5.7.5' type='text/css' media='all' />
    <link rel='stylesheet' id='slick-css' href='https://www.digitalclassworld.com/blog/wp-content/themes/covernews/assets/slick/css/slick.css?ver=5.7.5' type='text/css' media='all' />
    <link rel='stylesheet' id='covernews-google-fonts-css' href='https://fonts.googleapis.com/css?family=Source%20Sans%20Pro:400,400i,700,700i|Lato:400,300,400italic,900,700&#038;subset=latin,latin-ext' type='text/css' media='all' />

    
    
</head>

<body class="home page-template-default page page-id-521 custom-background wp-custom-logo wp-embed-responsive default-content-layout scrollup-sticky-header aft-sticky-header aft-sticky-sidebar default single-content-mode-default header-image-default full-width-content">
    
    <div class="jeg_ad jeg_ad_top jnews_header_top_ads">
        <div class='ads-wrapper  '></div>
    </div>
    <div>
        <div>
            <div class="jeg_header_instagram_wrapper"></div>
            <div class="jeg_header full">
                <div class="jeg_topbar jeg_container normal">
                    <div class="container">
                        <div class="jeg_nav_row">
                            <div class="jeg_nav_col jeg_nav_center  jeg_nav_normal">
                                <div class="item_wrap jeg_nav_aligncenter"></div>
                            </div>
                            <div class="jeg_nav_col jeg_nav_right  jeg_nav_normal">
                                <div class="social-navigation"><ul id="social-menu" class="menu"><li id="menu-item-107" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-107"><a href="https://www.facebook.com/digitalclassin/"><span class="screen-reader-text">Facebook</span></a></li>
                                    <li id="menu-item-108" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-108"><a href="https://www.instagram.com/digitalclassin/"><span class="screen-reader-text">Instagram</span></a></li>
                                    <li id="menu-item-109" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-109"><a href="https://www.youtube.com/digitalclass"><span class="screen-reader-text">Youtube</span></a></li>
                                    <li id="menu-item-110" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-110"><a href="https://www.linkedin.com/company/digitalclassin"><span class="screen-reader-text">Linkedin</span></a></li>
                                    <li id="menu-item-302" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-302"><a href="https://in.pinterest.com/digitalclassin/"><span class="screen-reader-text">Pinterest</span></a></li>
                                    <li id="menu-item-341" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-341"><a href="https://twitter.com/digitalclassin"><span class="screen-reader-text">Twitter</span></a></li>
                                    </ul></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="jeg_midbar jeg_container normal" style="background-color:rgb(177, 177, 177);">
                    <div class="container">
                        <div class="jeg_nav_row">
                            <div class="jeg_nav_col jeg_nav_left jeg_nav_grow">
                                <div class="item_wrap jeg_nav_alignleft"></div>
                            </div>
                            <div class="jeg_nav_col jeg_nav_center jeg_nav_normal">
                                <div class="item_wrap jeg_nav_aligncenter">
                                    <div class="jeg_nav_item jeg_logo jeg_desktop_logo">
                                        <img width="304" height="81" src="logo.png" class="custom-logo" alt="Best Blogs &amp; Insights From Digital Class E-Learning Marketplace" srcset="https://www.digitalclassworld.com/blog/wp-content/uploads/2021/07/cropped-logo_white.png 304w, https://www.digitalclassworld.com/blog/wp-content/uploads/2021/07/cropped-logo_white-300x80.png 300w" sizes="(max-width: 304px) 100vw, 304px">
                                    </div>
                                </div>
                            </div>
                            <div class="jeg_nav_col jeg_nav_right jeg_nav_grow">
                                <div class="item_wrap jeg_nav_alignright"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="jeg_bottombar jeg_navbar jeg_container jeg_navbar_wrapper jeg_navbar_normal jeg_navbar_normal">
                    <div class="container">
                        <div class="jeg_nav_row">
                            <div class="jeg_nav_col jeg_nav_left jeg_nav_grow">
                                <div class="item_wrap jeg_nav_alignleft">

                                </div>
                            </div>
                            <div class="jeg_nav_col jeg_nav_center jeg_nav_normal">
                                <div class="item_wrap jeg_nav_aligncenter">
                                    <div class="jeg_nav_item jeg_main_menu_wrapper">
                                        <div class="jeg_mainmenu_wrap">
                                            <ul class="jeg_menu jeg_main_menu jeg_menu_style_2" data-animation="animate">
                                                <li id="menu-item-199" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-43 current_page_item current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-199 bgnav"
                                                    data-item-row="default"><a href="https://www.digitalclassworld.com/blog/" aria-current="page">Home</a>
                                                </li>
                                                <li id="menu-item-364" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-364 bgnav" data-item-row="default"><a href="https://www.digitalclassworld.com/blog/about-digital-class/">Why us</a></li>
                                                <li id="menu-item-198" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-198 bgnav" data-item-row="default"><a href="https://digitalclassworld.com/e-learning/tutor-signup?utm_source=Blog&amp;utm_medium=Top_Menu">Publish Your Course on Marketplace</a></li>
                                                <li id="menu-item-195" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-195 bgnav" data-item-row="default"><a href="https://play.google.com/store/apps/details?id=com.digitalclass&amp;referrer=utm_source%3Dwebsite">Download App</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="jeg_nav_col jeg_nav_right jeg_nav_grow">
                                <div class="item_wrap jeg_nav_alignright">
                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="jeg_header_sticky">
        <div class="sticky_blankspace"></div>
        <div class="jeg_header full">
            <div class="jeg_container">
                
            </div>
        </div>
    </div>
    </div>
    <div class="jeg_navbar_mobile_wrapper">
        <div class="jeg_navbar_mobile" data-mode="scroll">
            <div class="jeg_mobile_bottombar jeg_mobile_midbar jeg_container normal">
                <div class="container">
                    <div class="jeg_nav_row">
                        <div class="jeg_nav_col jeg_nav_left jeg_nav_normal">
                            <div class="item_wrap jeg_nav_alignleft">
                                
                            </div>
                        </div>
                        <div class="jeg_nav_col jeg_nav_center jeg_nav_grow">
                            <div class="item_wrap jeg_nav_aligncenter">
                                <div style="background-color: rgb(177,177,177)" class="jeg_nav_item jeg_mobile_logo">
                                    <img width="304" height="81" src="logo.png" class="custom-logo" alt="Best Blogs &amp; Insights From Digital Class E-Learning Marketplace" srcset="https://www.digitalclassworld.com/blog/wp-content/uploads/2021/07/cropped-logo_white.png 304w, https://www.digitalclassworld.com/blog/wp-content/uploads/2021/07/cropped-logo_white-300x80.png 300w" sizes="(max-width: 304px) 100vw, 304px" data-pin-no-hover="true">
                                </div>
                            </div>
                        </div>
                        <div class="jeg_nav_col jeg_nav_right jeg_nav_normal">
                            <div class="item_wrap jeg_nav_alignright">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="sticky_blankspace" style="height: 60px;"></div>
    </div>
    <script type="text/javascript">
        var jfla = []
    </script>
    <script>
        window.ga = window.ga || function() {
            (ga.q = ga.q || []).push(arguments);
        };
        ga.l = +new Date;
        ga('create', 'UA-106493900-1', 'auto')
        ga('send', 'pageview')
    </script>
    <script>
        (function() {
            function maybePrefixUrlField() {
                if (this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
                    this.value = "http://" + this.value;
                }
            }

            var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
            if (urlFields) {
                for (var j = 0; j < urlFields.length; j++) {
                    urlFields[j].addEventListener('blur', maybePrefixUrlField);
                }
            }
        })();
    </script>
    <script type="text/html" id="wpb-modifications"></script>
    <script type='text/javascript' id='mediaelement-core-js-before'>
        var mejsL10n = {
            "language": "en",
            "strings": {
                "mejs.download-file": "Download File",
                "mejs.install-flash": "You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/",
                "mejs.fullscreen": "Fullscreen",
                "mejs.play": "Play",
                "mejs.pause": "Pause",
                "mejs.time-slider": "Time Slider",
                "mejs.time-help-text": "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.",
                "mejs.live-broadcast": "Live Broadcast",
                "mejs.volume-help-text": "Use Up\/Down Arrow keys to increase or decrease volume.",
                "mejs.unmute": "Unmute",
                "mejs.mute": "Mute",
                "mejs.volume-slider": "Volume Slider",
                "mejs.video-player": "Video Player",
                "mejs.audio-player": "Audio Player",
                "mejs.captions-subtitles": "Captions\/Subtitles",
                "mejs.captions-chapters": "Chapters",
                "mejs.none": "None",
                "mejs.afrikaans": "Afrikaans",
                "mejs.albanian": "Albanian",
                "mejs.arabic": "Arabic",
                "mejs.belarusian": "Belarusian",
                "mejs.bulgarian": "Bulgarian",
                "mejs.catalan": "Catalan",
                "mejs.chinese": "Chinese",
                "mejs.chinese-simplified": "Chinese (Simplified)",
                "mejs.chinese-traditional": "Chinese (Traditional)",
                "mejs.croatian": "Croatian",
                "mejs.czech": "Czech",
                "mejs.danish": "Danish",
                "mejs.dutch": "Dutch",
                "mejs.english": "English",
                "mejs.estonian": "Estonian",
                "mejs.filipino": "Filipino",
                "mejs.finnish": "Finnish",
                "mejs.french": "French",
                "mejs.galician": "Galician",
                "mejs.german": "German",
                "mejs.greek": "Greek",
                "mejs.haitian-creole": "Haitian Creole",
                "mejs.hebrew": "Hebrew",
                "mejs.hindi": "Hindi",
                "mejs.hungarian": "Hungarian",
                "mejs.icelandic": "Icelandic",
                "mejs.indonesian": "Indonesian",
                "mejs.irish": "Irish",
                "mejs.italian": "Italian",
                "mejs.japanese": "Japanese",
                "mejs.korean": "Korean",
                "mejs.latvian": "Latvian",
                "mejs.lithuanian": "Lithuanian",
                "mejs.macedonian": "Macedonian",
                "mejs.malay": "Malay",
                "mejs.maltese": "Maltese",
                "mejs.norwegian": "Norwegian",
                "mejs.persian": "Persian",
                "mejs.polish": "Polish",
                "mejs.portuguese": "Portuguese",
                "mejs.romanian": "Romanian",
                "mejs.russian": "Russian",
                "mejs.serbian": "Serbian",
                "mejs.slovak": "Slovak",
                "mejs.slovenian": "Slovenian",
                "mejs.spanish": "Spanish",
                "mejs.swahili": "Swahili",
                "mejs.swedish": "Swedish",
                "mejs.tagalog": "Tagalog",
                "mejs.thai": "Thai",
                "mejs.turkish": "Turkish",
                "mejs.ukrainian": "Ukrainian",
                "mejs.vietnamese": "Vietnamese",
                "mejs.welsh": "Welsh",
                "mejs.yiddish": "Yiddish"
            }
        };
    </script>
    <script type='text/javascript' id='mediaelement-js-extra'>
        var _wpmejsSettings = {
            "pluginPath": "\/yoga\/wp-includes\/js\/mediaelement\/",
            "classPrefix": "mejs-",
            "stretching": "responsive"
        };
    </script>
    <script type='text/javascript' id='jnews-main-js-extra'>
        var jnewsoption = {
            "login_reload": "https:\/\/jnews.io\/yoga",
            "popup_script": "magnific",
            "single_gallery": "",
            "ismobile": "",
            "isie": "",
            "sidefeed_ajax": "",
            "language": "en_US",
            "module_prefix": "jnews_module_ajax_",
            "live_search": "1",
            "postid": "0",
            "isblog": "",
            "admin_bar": "0",
            "follow_video": "",
            "follow_position": "top_right",
            "rtl": "0",
            "gif": "",
            "lang": {
                "invalid_recaptcha": "Invalid Recaptcha!",
                "empty_username": "Please enter your username!",
                "empty_email": "Please enter your email!",
                "empty_password": "Please enter your password!"
            },
            "recaptcha": "0",
            "site_slug": "\/yoga\/",
            "site_domain": "jnews.io",
            "zoom_button": "0"
        };
    </script>
    <script type='application/ld+json'>
        {
            "@context": "http:\/\/schema.org",
            "@type": "ItemList",
            "url": "https:\/\/jnews.io\/yoga",
            "itemListElement": [{
                "@type": "ListItem",
                "position": 1,
                "item": {
                    "name": "Pranayama: The Beginner\u2019s Guide to Yoga Breathing Exercises",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/17\/pranayama-the-beginners-guide-to-yoga-breathing-exercises\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=21",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-1.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 2,
                "item": {
                    "name": "Yoga is the journey of the self, through the self, to the self",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/14\/yoga-is-the-journey-of-the-self-through-the-self-to-the-self\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=22",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-2.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 3,
                "item": {
                    "name": "Five Yoga Poses You Should Do First Thing in the Morning",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/11\/five-yoga-poses-you-should-do-first-thing-in-the-morning\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=19",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-7.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 4,
                "item": {
                    "name": "<strong>Best New Songs<\/strong> <em>for<\/em> Your Yoga Music <em>Playlist<\/em>",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/17\/best-new-songs-for-your-yoga-music-playlist\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=17",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/04\/jnews-9.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 5,
                "item": {
                    "name": "Meditation Tips: Natural Ways to Improve Concentration and Focus",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/16\/meditation-tips-natural-ways-to-improve-concentration-and-focus\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=28",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-4.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 6,
                "item": {
                    "name": "The Best Yoga Moves To Improve Shoulder Flexibility",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/16\/the-best-yoga-moves-to-improve-shoulder-flexibility\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=29",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-19.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 7,
                "item": {
                    "name": "Amazing Yoga Retreats with Rice Field View in Ubud You Should Visit",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/16\/amazing-yoga-retreats-with-rice-field-view-in-ubud-you-should-visit\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=15",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-3.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 8,
                "item": {
                    "name": "These Yoga Poses Will Help You Take Better Care of Yourself",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/24\/these-yoga-poses-will-help-you-take-better-care-of-yourself\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=16",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/04\/jnews-14.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 9,
                "item": {
                    "name": "Beginner&#8217;s Guide: Step-by-Step Yoga Pose Instruction from Yoga Expert",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/20\/beginners-guide-step-by-step-yoga-pose-instruction-from-yoga-expert\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=24",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-24.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 10,
                "item": {
                    "name": "The Important Things to Know Before Planning an International Yoga Retreat",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/10\/the-important-things-to-know-before-planning-an-international-yoga-retreat\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=38",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-29.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 11,
                "item": {
                    "name": "Beginner&#8217;s Guide: Basic Tips to Get Started With Yoga",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/30\/beginners-guide-basic-tips-to-get-started-with-yoga\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=18",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-12.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 12,
                "item": {
                    "name": "Five Reasons Why Children Need to Learn Yoga and Meditate",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/29\/five-reasons-why-children-need-to-learn-yoga-and-meditate\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=31",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-18-1.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 13,
                "item": {
                    "name": "Mindfulness With Yoga: Powerful Exercises for Peace and Happiness",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/28\/mindfulness-with-yoga-powerful-exercises-for-peace-and-happiness\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=20",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-20.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 14,
                "item": {
                    "name": "Here is How Meditation Can Reduce Stress and Bring Health Inside Out",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/23\/here-is-how-meditation-can-reduce-stress-and-bring-health-inside-out\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=25",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-22.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 15,
                "item": {
                    "name": "Ayurveda&#8217;s 10 Best Flu Survival Tips for a Speedy Recovery",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/19\/ayurvedas-10-best-flu-survival-tips-for-a-speedy-recovery\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=39",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-31.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 16,
                "item": {
                    "name": "How to Find Deeper Access to Joy: Start with a Peaceful Mind",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/18\/how-to-find-deeper-access-to-joy-start-with-a-peaceful-mind\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=37",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-28.jpg"
                }
            }, {
                "@type": "ListItem",
                "position": 17,
                "item": {
                    "name": "Benefits of Meditation: 10 Reasons Why You Should Learn Meditate",
                    "@id": "https:\/\/jnews.io\/yoga\/2018\/03\/17\/benefits-of-meditation-10-reasons-why-you-should-learn-meditate\/",
                    "url": "https:\/\/jnews.io\/yoga\/?post_type=post&p=30",
                    "image": "https:\/\/jnews.io\/yoga\/wp-content\/uploads\/sites\/41\/2018\/03\/jnews-26.jpg"
                }
            }]
        }
    </script>
    <script type='application/ld+json'>
        {
            "@context": "http:\/\/schema.org",
            "@type": "Webpage",
            "headline": "Home 1",
            "url": "https:\/\/jnews.io\/yoga\/"
        }
    </script>
    <style id="jeg_dynamic_css" type="text/css" data-type="jeg_custom-css">
        body {
            --j-body-color: #343536;
            --j-accent-color: #8789c0;
            --j-alt-color: #5dfdcb;
            --j-heading-color: #161925;
        }

        body,
        .jeg_newsfeed_list .tns-outer .tns-controls button,
        .jeg_filter_button,
        .owl-carousel .owl-nav div,
        .jeg_readmore,
        .jeg_hero_style_7 .jeg_post_meta a,
        .widget_calendar thead th,
        .widget_calendar tfoot a,
        .jeg_socialcounter a,
        .entry-header .jeg_meta_like a,
        .entry-header .jeg_meta_comment a,
        .entry-content tbody tr:hover,
        .entry-content th,
        .jeg_splitpost_nav li:hover a,
        #breadcrumbs a,
        .jeg_author_socials a:hover,
        .jeg_footer_content a,
        .jeg_footer_bottom a,
        .jeg_cartcontent,
        .woocommerce .woocommerce-breadcrumb a {
            color: #343536;
        }

        a,
        .jeg_menu_style_5>li>a:hover,
        .jeg_menu_style_5>li.sfHover>a,
        .jeg_menu_style_5>li.current-menu-item>a,
        .jeg_menu_style_5>li.current-menu-ancestor>a,
        .jeg_navbar .jeg_menu:not(.jeg_main_menu)>li>a:hover,
        .jeg_midbar .jeg_menu:not(.jeg_main_menu)>li>a:hover,
        .jeg_side_tabs li.active,
        .jeg_block_heading_5 strong,
        .jeg_block_heading_6 strong,
        .jeg_block_heading_7 strong,
        .jeg_block_heading_8 strong,
        .jeg_subcat_list li a:hover,
        .jeg_subcat_list li button:hover,
        .jeg_pl_lg_7 .jeg_thumb .jeg_post_category a,
        .jeg_pl_xs_2:before,
        .jeg_pl_xs_4 .jeg_postblock_content:before,
        .jeg_postblock .jeg_post_title a:hover,
        .jeg_hero_style_6 .jeg_post_title a:hover,
        .jeg_sidefeed .jeg_pl_xs_3 .jeg_post_title a:hover,
        .widget_jnews_popular .jeg_post_title a:hover,
        .jeg_meta_author a,
        .widget_archive li a:hover,
        .widget_pages li a:hover,
        .widget_meta li a:hover,
        .widget_recent_entries li a:hover,
        .widget_rss li a:hover,
        .widget_rss cite,
        .widget_categories li a:hover,
        .widget_categories li.current-cat>a,
        #breadcrumbs a:hover,
        .jeg_share_count .counts,
        .commentlist .bypostauthor>.comment-body>.comment-author>.fn,
        span.required,
        .jeg_review_title,
        .bestprice .price,
        .authorlink a:hover,
        .jeg_vertical_playlist .jeg_video_playlist_play_icon,
        .jeg_vertical_playlist .jeg_video_playlist_item.active .jeg_video_playlist_thumbnail:before,
        .jeg_horizontal_playlist .jeg_video_playlist_play,
        .woocommerce li.product .pricegroup .button,
        .widget_display_forums li a:hover,
        .widget_display_topics li:before,
        .widget_display_replies li:before,
        .widget_display_views li:before,
        .bbp-breadcrumb a:hover,
        .jeg_mobile_menu li.sfHover>a,
        .jeg_mobile_menu li a:hover,
        .split-template-6 .pagenum,
        .jeg_mobile_menu_style_5>li>a:hover,
        .jeg_mobile_menu_style_5>li.sfHover>a,
        .jeg_mobile_menu_style_5>li.current-menu-item>a,
        .jeg_mobile_menu_style_5>li.current-menu-ancestor>a {
            color: #8789c0;
        }

        .jeg_menu_style_1>li>a:before,
        .jeg_menu_style_2>li>a:before,
        .jeg_menu_style_3>li>a:before,
        .jeg_side_toggle,
        .jeg_slide_caption .jeg_post_category a,
        .jeg_slider_type_1_wrapper .tns-controls button.tns-next,
        .jeg_block_heading_1 .jeg_block_title span,
        .jeg_block_heading_2 .jeg_block_title span,
        .jeg_block_heading_3,
        .jeg_block_heading_4 .jeg_block_title span,
        .jeg_block_heading_6:after,
        .jeg_pl_lg_box .jeg_post_category a,
        .jeg_pl_md_box .jeg_post_category a,
        .jeg_readmore:hover,
        .jeg_thumb .jeg_post_category a,
        .jeg_block_loadmore a:hover,
        .jeg_postblock.alt .jeg_block_loadmore a:hover,
        .jeg_block_loadmore a.active,
        .jeg_postblock_carousel_2 .jeg_post_category a,
        .jeg_heroblock .jeg_post_category a,
        .jeg_pagenav_1 .page_number.active,
        .jeg_pagenav_1 .page_number.active:hover,
        input[type="submit"],
        .btn,
        .button,
        .widget_tag_cloud a:hover,
        .popularpost_item:hover .jeg_post_title a:before,
        .jeg_splitpost_4 .page_nav,
        .jeg_splitpost_5 .page_nav,
        .jeg_post_via a:hover,
        .jeg_post_source a:hover,
        .jeg_post_tags a:hover,
        .comment-reply-title small a:before,
        .comment-reply-title small a:after,
        .jeg_storelist .productlink,
        .authorlink li.active a:before,
        .jeg_footer.dark .socials_widget:not(.nobg) a:hover .fa,
        div.jeg_breakingnews_title,
        .jeg_overlay_slider_bottom_wrapper .tns-controls button,
        .jeg_overlay_slider_bottom_wrapper .tns-controls button:hover,
        .jeg_vertical_playlist .jeg_video_playlist_current,
        .woocommerce span.onsale,
        .woocommerce #respond input#submit:hover,
        .woocommerce a.button:hover,
        .woocommerce button.button:hover,
        .woocommerce input.button:hover,
        .woocommerce #respond input#submit.alt,
        .woocommerce a.button.alt,
        .woocommerce button.button.alt,
        .woocommerce input.button.alt,
        .jeg_popup_post .caption,
        .jeg_footer.dark input[type="submit"],
        .jeg_footer.dark .btn,
        .jeg_footer.dark .button,
        .footer_widget.widget_tag_cloud a:hover,
        .jeg_inner_content .content-inner .jeg_post_category a:hover,
        #buddypress .standard-form button,
        #buddypress a.button,
        #buddypress input[type="submit"],
        #buddypress input[type="button"],
        #buddypress input[type="reset"],
        #buddypress ul.button-nav li a,
        #buddypress .generic-button a,
        #buddypress .generic-button button,
        #buddypress .comment-reply-link,
        #buddypress a.bp-title-button,
        #buddypress.buddypress-wrap .members-list li .user-update .activity-read-more a,
        div#buddypress .standard-form button:hover,
        div#buddypress a.button:hover,
        div#buddypress input[type="submit"]:hover,
        div#buddypress input[type="button"]:hover,
        div#buddypress input[type="reset"]:hover,
        div#buddypress ul.button-nav li a:hover,
        div#buddypress .generic-button a:hover,
        div#buddypress .generic-button button:hover,
        div#buddypress .comment-reply-link:hover,
        div#buddypress a.bp-title-button:hover,
        div#buddypress.buddypress-wrap .members-list li .user-update .activity-read-more a:hover,
        #buddypress #item-nav .item-list-tabs ul li a:before,
        .jeg_inner_content .jeg_meta_container .follow-wrapper a {
            background-color: #8789c0;
        }

        .jeg_block_heading_7 .jeg_block_title span,
        .jeg_readmore:hover,
        .jeg_block_loadmore a:hover,
        .jeg_block_loadmore a.active,
        .jeg_pagenav_1 .page_number.active,
        .jeg_pagenav_1 .page_number.active:hover,
        .jeg_pagenav_3 .page_number:hover,
        .jeg_prevnext_post a:hover h3,
        .jeg_overlay_slider .jeg_post_category,
        .jeg_sidefeed .jeg_post.active,
        .jeg_vertical_playlist.jeg_vertical_playlist .jeg_video_playlist_item.active .jeg_video_playlist_thumbnail img,
        .jeg_horizontal_playlist .jeg_video_playlist_item.active {
            border-color: #8789c0;
        }

        .jeg_tabpost_nav li.active,
        .woocommerce div.product .woocommerce-tabs ul.tabs li.active,
        .jeg_mobile_menu_style_1>li.current-menu-item a,
        .jeg_mobile_menu_style_1>li.current-menu-ancestor a,
        .jeg_mobile_menu_style_2>li.current-menu-item::after,
        .jeg_mobile_menu_style_2>li.current-menu-ancestor::after,
        .jeg_mobile_menu_style_3>li.current-menu-item::before,
        .jeg_mobile_menu_style_3>li.current-menu-ancestor::before {
            border-bottom-color: #8789c0;
        }

        .jeg_post_meta .fa,
        .entry-header .jeg_post_meta .fa,
        .jeg_review_stars,
        .jeg_price_review_list {
            color: #5dfdcb;
        }

        .jeg_share_button.share-float.share-monocrhome a {
            background-color: #5dfdcb;
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .jeg_post_title a,
        .entry-header .jeg_post_title,
        .jeg_hero_style_7 .jeg_post_title a,
        .jeg_block_title,
        .jeg_splitpost_bar .current_title,
        .jeg_video_playlist_title,
        .gallery-caption,
        .jeg_push_notification_button>a.button {
            color: #161925;
        }

        .split-template-9 .pagenum,
        .split-template-10 .pagenum,
        .split-template-11 .pagenum,
        .split-template-12 .pagenum,
        .split-template-13 .pagenum,
        .split-template-15 .pagenum,
        .split-template-18 .pagenum,
        .split-template-20 .pagenum,
        .split-template-19 .current_title span,
        .split-template-20 .current_title span {
            background-color: #161925;
        }

        .jeg_topbar .jeg_nav_row,
        .jeg_topbar .jeg_search_no_expand .jeg_search_input {
            line-height: 48px;
        }

        .jeg_topbar .jeg_nav_row,
        .jeg_topbar .jeg_nav_icon {
            height: 48px;
        }

        .jeg_topbar,
        .jeg_topbar.dark,
        .jeg_topbar.custom {
            background: #ffffff;
        }

        .jeg_topbar,
        .jeg_topbar.dark {
            border-color: #ffffff;
        }

        .jeg_topbar .jeg_nav_item,
        .jeg_topbar.dark .jeg_nav_item {
            border-color: #ffffff;
        }

        .jeg_midbar {
            height: 130px;
        }

        .jeg_midbar,
        .jeg_midbar.dark {
            background-color: #ffffff;
        }

        .jeg_header .jeg_bottombar.jeg_navbar,
        .jeg_bottombar .jeg_nav_icon {
            height: 50px;
        }

        .jeg_header .jeg_bottombar.jeg_navbar,
        .jeg_header .jeg_bottombar .jeg_main_menu:not(.jeg_menu_style_1)>li>a,
        .jeg_header .jeg_bottombar .jeg_menu_style_1>li,
        .jeg_header .jeg_bottombar .jeg_menu:not(.jeg_main_menu)>li>a {
            line-height: 50px;
        }

        .jeg_header .jeg_bottombar.jeg_navbar_wrapper:not(.jeg_navbar_boxed),
        .jeg_header .jeg_bottombar.jeg_navbar_boxed .jeg_nav_row {
            background: #e7ecff;
        }

        .jeg_header .jeg_bottombar a,
        .jeg_header .jeg_bottombar.jeg_navbar_dark a {
            color: #606389;
        }

        .jeg_header .jeg_bottombar,
        .jeg_header .jeg_bottombar.jeg_navbar_dark,
        .jeg_bottombar.jeg_navbar_boxed .jeg_nav_row,
        .jeg_bottombar.jeg_navbar_dark.jeg_navbar_boxed .jeg_nav_row {
            border-bottom-width: 0px;
        }

        .jeg_stickybar,
        .jeg_stickybar.dark {
            border-bottom-width: 0px;
        }

        .jeg_mobile_midbar,
        .jeg_mobile_midbar.dark {
            background: #e7ecff;
        }

        .jeg_header .socials_widget>a>i.fa:before {
            color: #161925;
        }

        .jeg_header .socials_widget.nobg>a>span.jeg-icon svg {
            fill: #161925;
        }

        .jeg_header .socials_widget>a>span.jeg-icon svg {
            fill: #161925;
        }

        .jeg_aside_item.socials_widget>a>i.fa:before {
            color: #161925;
        }

        .jeg_aside_item.socials_widget.nobg a span.jeg-icon svg {
            fill: #161925;
        }

        .jeg_aside_item.socials_widget a span.jeg-icon svg {
            fill: #161925;
        }

        .jeg_nav_icon .jeg_mobile_toggle.toggle_btn {
            color: #161925;
        }

        .jeg_navbar_mobile_wrapper .jeg_nav_item a.jeg_mobile_toggle,
        .jeg_navbar_mobile_wrapper .dark .jeg_nav_item a.jeg_mobile_toggle {
            color: #161925;
        }

        .jeg_header .jeg_search_wrapper.search_icon .jeg_search_toggle {
            color: #161925;
        }

        .jeg_header .jeg_search_popup_expand .jeg_search_result a,
        .jeg_header .jeg_search_popup_expand .jeg_search_result .search-link {
            color: #161925;
        }

        .jeg_navbar_mobile .jeg_search_wrapper .jeg_search_toggle,
        .jeg_navbar_mobile .dark .jeg_search_wrapper .jeg_search_toggle {
            color: #161925;
        }

        .jeg_nav_search {
            width: 64%;
        }

        .jeg_header .jeg_search_no_expand .jeg_search_result a,
        .jeg_header .jeg_search_no_expand .jeg_search_result .search-link {
            color: #041d28;
        }

        .jeg_header .jeg_menu.jeg_main_menu>li>a {
            color: #161925;
        }

        .jeg_menu_style_1>li>a:before,
        .jeg_menu_style_2>li>a:before,
        .jeg_menu_style_3>li>a:before {
            background: rgba(255, 255, 255, 0.25);
        }

        .jeg_footer_content,
        .jeg_footer.dark .jeg_footer_content {
            background-color: #f7f7fa;
        }

        body,
        input,
        textarea,
        select,
        .chosen-container-single .chosen-single,
        .btn,
        .button {
            font-family: Raleway, Helvetica, Arial, sans-serif;
        }

        .jeg_header,
        .jeg_mobile_wrapper {
            font-family: "Work Sans", Helvetica, Arial, sans-serif;
        }

        .jeg_main_menu>li>a {
            font-family: "Work Sans", Helvetica, Arial, sans-serif;
            font-weight: 500;
            font-style: normal;
            font-size: 16px;
        }

        .jeg_post_title,
        .entry-header .jeg_post_title,
        .jeg_single_tpl_2 .entry-header .jeg_post_title,
        .jeg_single_tpl_3 .entry-header .jeg_post_title,
        .jeg_single_tpl_6 .entry-header .jeg_post_title,
        .jeg_content .jeg_custom_title_wrapper .jeg_post_title {
            font-family: Lora, Helvetica, Arial, sans-serif;
        }

        .jeg_thumb .jeg_post_category a,
        .jeg_pl_lg_box .jeg_post_category a,
        .jeg_pl_md_box .jeg_post_category a,
        .jeg_postblock_carousel_2 .jeg_post_category a,
        .jeg_heroblock .jeg_post_category a,
        .jeg_slide_caption .jeg_post_category a {
            background-color: #8789c0;
            color: #ffffff;
        }

        .jeg_overlay_slider .jeg_post_category,
        .jeg_thumb .jeg_post_category a,
        .jeg_pl_lg_box .jeg_post_category a,
        .jeg_pl_md_box .jeg_post_category a,
        .jeg_postblock_carousel_2 .jeg_post_category a,
        .jeg_heroblock .jeg_post_category a,
        .jeg_slide_caption .jeg_post_category a {
            border-color: #8789c0;
        }
    </style>
    <style type="text/css">
        .no_thumbnail .jeg_thumb,
        .thumbnail-container.no_thumbnail {
            display: none !important;
        }

        .jeg_search_result .jeg_pl_xs_3.no_thumbnail .jeg_postblock_content,
        .jeg_sidefeed .jeg_pl_xs_3.no_thumbnail .jeg_postblock_content,
        .jeg_pl_sm.no_thumbnail .jeg_postblock_content {
            margin-left: 0;
        }

        .jeg_postblock_11 .no_thumbnail .jeg_postblock_content,
        .jeg_postblock_12 .no_thumbnail .jeg_postblock_content,
        .jeg_postblock_12.jeg_col_3o3 .no_thumbnail .jeg_postblock_content {
            margin-top: 0;
        }

        .jeg_postblock_15 .jeg_pl_md_box.no_thumbnail .jeg_postblock_content,
        .jeg_postblock_19 .jeg_pl_md_box.no_thumbnail .jeg_postblock_content,
        .jeg_postblock_24 .jeg_pl_md_box.no_thumbnail .jeg_postblock_content,
        .jeg_sidefeed .jeg_pl_md_box .jeg_postblock_content {
            position: relative;
        }

        .jeg_postblock_carousel_2 .no_thumbnail .jeg_post_title a,
        .jeg_postblock_carousel_2 .no_thumbnail .jeg_post_title a:hover,
        .jeg_postblock_carousel_2 .no_thumbnail .jeg_post_meta .fa {
            color: #212121 !important;
        }
    </style>
    <style id="jeg_vc_custom_css" type="text/css" data-type="jeg_vc_custom-css">
        .jeg_main_content .mc4wp-form input[type="text"],
        .jeg_main_content .mc4wp-form input[type="email"] {
            border-color: #d7e4e1;
        }

        .jeg_inline_subscribeform .mc4wp-form h3 {
            font-family: Lora;
            font-weight: normal;
            font-style: italic;
        }

        .jeg_block_heading_7 .jeg_block_title,
        .jeg_block_heading_8 .jeg_block_title {
            float: none;
            font-size: 14px;
            letter-spacing: 2px;
        }

        .jeg_block_heading_7 .jeg_block_title,
        .jeg_block_heading_8 .jeg_block_title {
            text-align: center;
        }

        .jeg_postblock_5 .jeg_readmore {
            display: none;
        }
    </style>
    <style id="jeg_vc_shortcodes_css" type="text/css" data-type="jeg_vc_shortcodes_custom-css">
        .vc_custom_1525340422816 {
            background-color: #f4f4f9 !important;
        }

        .vc_custom_1525335203183 {
            padding-top: 25px !important;
            padding-right: 30px !important;
            padding-bottom: 25px !important;
            padding-left: 30px !important;
            background-color: #e4f9f3 !important;
        }

        .vc_custom_1525843895748 {
            border-top-width: 1px !important;
            border-right-width: 1px !important;
            border-bottom-width: 1px !important;
            border-left-width: 1px !important;
            padding-top: 15px !important;
            padding-right: 20px !important;
            padding-bottom: 10px !important;
            padding-left: 20px !important;
            border-left-color: #eeeeee !important;
            border-left-style: solid !important;
            border-right-color: #eeeeee !important;
            border-right-style: solid !important;
            border-top-color: #eeeeee !important;
            border-top-style: solid !important;
            border-bottom-color: #eeeeee !important;
            border-bottom-style: solid !important;
        }
    </style>
    <script>
        jnewsads = window.jnewsads || [], "object" == typeof jnewsads && "object" == typeof jnews.library && (jnews.library.objKeys(jnewsads).forEach((function(s) {
            jnews.library.assets = jnews.library.assets || [], jnews.library.assets.indexOf(jnewsads[s]) < 0 && jnews.library.assets.push(jnewsads[s])
        })), jnews.library.winLoad((function() {
            setTimeout((function() {
                if ("object" == typeof jnewsads && jnewsads.length) {
                    var s = jnewsads.slice(0);
                    jnews.library.objKeys(s).forEach((function(e) {
                        jnews.library.assets = jnews.library.assets || [];
                        var a = jnews.library.assets.indexOf(s[e]);
                        a > -1 && jnews.library.assets.splice(a, 1), (a = jnewsads.indexOf(s[e])) > -1 && jnewsads.splice(a, 1), jnews.library.create_js(s[e].url, "deferasync")
                    }))
                }
            }), 3e3)
        })));
    </script>
    <script type="text/javascript">
        ;
        ! function() {
            "use strict";
            window.jnews = window.jnews || {}, window.jnews.first_load = window.jnews.first_load || {}, window.jnews.first_load = function() {
                var e = this,
                    t = jnews.library,
                    n = "object" == typeof jnews && "object" == typeof jnews.library;
                e.data = null, e.run_ajax = !0, e.run_loginregister = !0, e.clear = function() {
                    e.run_ajax = !0, e.run_loginregister = !0, e.data = null
                }, e.init = function() {
                    n && (t.globalBody.querySelectorAll(".jeg_popup_account").length && jnews.loginregister && e.run_loginregister && (e.run_loginregister = !1, jnews.loginregister.init(), jnews.loginregister.hook_form()), jfla.length && e.run_ajax && (e.run_ajax = !1, e.do_ajax({
                        action: "jnews_first_load_action",
                        jnews_id: jnewsoption.postid,
                        load_action: jfla
                    })))
                }, e.update_counter = function() {
                    if (n) {
                        var o = {
                            total_view: t.globalBody.querySelectorAll(".jeg_share_stats .jeg_views_count .counts"),
                            total_share: t.globalBody.querySelectorAll(".jeg_share_stats .jeg_share_count .counts"),
                            total_comment: t.globalBody.querySelectorAll(".jeg_meta_comment a span")
                        };
                        t.forEach(Object.entries(e.data.counter), (function([e, n]) {
                            o[e].length && t.forEach(o[e], (function(e, o) {
                                t.setText(e, n)
                            }))
                        }))
                    }
                }, e.do_ajax = function(o) {
                    if (n) {
                        var a = new XMLHttpRequest;
                        a.onreadystatechange = function() {
                            XMLHttpRequest.DONE === a.readyState && 200 == a.status && (e.data = JSON.parse(a.responseText), e.data.counter && "object" == typeof e.data.counter && e.update_counter())
                        }, a.open("POST", jnews_ajax_url, !0), a.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8"), a.send(t.httpBuildQuery(o))
                    }
                }
            }, window.jnews.first_load = new window.jnews.first_load, jnews.first_load.init()
        }();
    </script>
    <script>
        var jnewsoption = jnewsoption || {};
        jnewsoption.au_scripts = [{
            "url": "https:\/\/jnews.io\/yoga\/wp-content\/cache\/autoptimize\/41\/js\/autoptimize_c5d64e060864cca2a21ebd297dfb5dc3.js",
            "defer": true
        }];
    </script>
    <script>
        var _0x5ef2 = ['doc', 'removeEvents', 'assets', 'addEvents', '2QnwLpJ', '1POAEyY', 'library', 'push', '74485JvACyy', '174718HgLdee', '39510sMSFDR', '83719DWYYao', 'win', '7XLEWuh', 'length', '192626gsIanL', '16vzPwGL', '5GdvQlS', 'au_scripts', '5GlcxuY', '157426WkzrxI', '18077FFTiBj', 'objKeys'];
        var _0x55d85c = _0x5591;
        (function(_0x1b9ddd, _0x5edf80) {
            var _0xf1eac1 = _0x5591;
            while (!![]) {
                try {
                    var _0x4da144 = parseInt(_0xf1eac1(0xc5)) * -parseInt(_0xf1eac1(0xba)) + parseInt(_0xf1eac1(0xbd)) * parseInt(_0xf1eac1(0xc3)) + -parseInt(_0xf1eac1(0xbf)) * -parseInt(_0xf1eac1(0xbc)) + -parseInt(_0xf1eac1(0xbb)) * parseInt(_0xf1eac1(0xb6)) + parseInt(_0xf1eac1(0xb7)) * parseInt(_0xf1eac1(0xc6)) + -parseInt(_0xf1eac1(0xc2)) * -parseInt(_0xf1eac1(0xc7)) + -parseInt(_0xf1eac1(0xc1));
                    if (_0x4da144 === _0x5edf80) break;
                    else _0x1b9ddd['push'](_0x1b9ddd['shift']());
                } catch (_0x46e6d9) {
                    _0x1b9ddd['push'](_0x1b9ddd['shift']());
                }
            }
        }(_0x5ef2, 0x37808), jnews[_0x55d85c(0xb8)][_0x55d85c(0xb1)](jnewsoption[_0x55d85c(0xc4)])['forEach'](function(_0x312399) {
            var _0x4cf9c0 = _0x55d85c;
            jnews[_0x4cf9c0(0xb8)][_0x4cf9c0(0xb4)] = jnews[_0x4cf9c0(0xb8)][_0x4cf9c0(0xb4)] || [], jnews[_0x4cf9c0(0xb8)][_0x4cf9c0(0xb4)][_0x4cf9c0(0xb9)](jnewsoption[_0x4cf9c0(0xc4)][_0x312399]);
        }));

        function _0x5591(_0x110992, _0x59223d) {
            _0x110992 = _0x110992 - 0xb1;
            var _0x5ef276 = _0x5ef2[_0x110992];
            return _0x5ef276;
        }
        var earlyEvents = function() {
                var _0x142f52 = _0x55d85c;
                jnews[_0x142f52(0xb8)][_0x142f52(0xb4)] = jnews['library'][_0x142f52(0xb4)] || [], jnews[_0x142f52(0xb8)][_0x142f52(0xb4)][_0x142f52(0xc0)] ? jnews[_0x142f52(0xb8)]['fireOnce']() : (jnews[_0x142f52(0xb8)][_0x142f52(0xb3)](jnews[_0x142f52(0xb8)][_0x142f52(0xb2)], listEarlyEvents), jnews[_0x142f52(0xb8)][_0x142f52(0xb3)](jnews[_0x142f52(0xb8)][_0x142f52(0xbe)], listEarlyEventsWindow));
            },
            listEarlyEvents = {
                'click': earlyEvents,
                'mousemove': earlyEvents,
                'mousewheel': earlyEvents,
                'scroll': earlyEvents,
                'touchmove': earlyEvents
            },
            listEarlyEventsWindow = {
                'scroll': earlyEvents,
                'focus': earlyEvents
            };
        jnews['library'][_0x55d85c(0xb5)](jnews[_0x55d85c(0xb8)][_0x55d85c(0xb2)], listEarlyEvents), jnews[_0x55d85c(0xb8)]['addEvents'](jnews[_0x55d85c(0xb8)][_0x55d85c(0xbe)], listEarlyEventsWindow);
    </script>
    <script type="text/javascript">
        ! function(e, t) {
            var n = function(e, t) {
                "use strict";
                if (!t.getElementsByClassName) return;
                var n, a = t.documentElement,
                    i = e.Date,
                    o = e.HTMLPictureElement,
                    r = "addEventListener",
                    s = "getAttribute",
                    l = e[r],
                    d = e.setTimeout,
                    c = e.requestAnimationFrame || d,
                    u = e.requestIdleCallback,
                    f = /^picture$/i,
                    m = ["load", "error", "lazyincluded", "_lazyloaded"],
                    v = {},
                    g = Array.prototype.forEach,
                    h = function(e, t) {
                        return v[t] || (v[t] = new RegExp("(\\s|^)" + t + "(\\s|$)")), v[t].test(e[s]("class") || "") && v[t]
                    },
                    z = function(e, t) {
                        h(e, t) || e.setAttribute("class", (e[s]("class") || "").trim() + " " + t)
                    },
                    y = function(e, t) {
                        var n;
                        (n = h(e, t)) && e.setAttribute("class", (e[s]("class") || "").replace(n, " "))
                    },
                    p = function(e, t, n) {
                        var a = n ? r : "removeEventListener";
                        n && p(e, t), m.forEach((function(n) {
                            e[a](n, t)
                        }))
                    },
                    C = function(e, n, a, i, o) {
                        var r = t.createEvent("CustomEvent");
                        return r.initCustomEvent(n, !i, !o, a || {}), e.dispatchEvent(r), r
                    },
                    b = function(t, a) {
                        var i;
                        !o && (i = e.picturefill || n.pf) ? i({
                            reevaluate: !0,
                            elements: [t]
                        }) : a && a.src && (t.src = a.src)
                    },
                    A = function(e, t) {
                        return (getComputedStyle(e, null) || {})[t]
                    },
                    E = function(e, t, a) {
                        for (a = a || e.offsetWidth; a < n.minSize && t && !e._lazysizesWidth;) a = t.offsetWidth, t = t.parentNode;
                        return a
                    },
                    N = (P = [], T = [], $ = function() {
                        var e = P;
                        for (P = T, k = !0, O = !1; e.length;) e.shift()();
                        k = !1
                    }, D = function(e, n) {
                        k && !n ? e.apply(this, arguments) : (P.push(e), O || (O = !0, (t.hidden ? d : c)($)))
                    }, D._lsFlush = $, D),
                    w = function(e, t) {
                        return t ? function() {
                            N(e)
                        } : function() {
                            var t = this,
                                n = arguments;
                            N((function() {
                                e.apply(t, n)
                            }))
                        }
                    },
                    M = function(e) {
                        var t, n = 0,
                            a = 125,
                            o = 66,
                            r = o,
                            s = function() {
                                t = !1, n = i.now(), e()
                            },
                            l = u ? function() {
                                u(s, {
                                    timeout: r
                                }), r !== o && (r = o)
                            } : w((function() {
                                d(s)
                            }), !0);
                        return function(e) {
                            var o;
                            (e = !0 === e) && (r = 44), t || (t = !0, (o = a - (i.now() - n)) < 0 && (o = 0), e || o < 9 && u ? l() : d(l, o))
                        }
                    },
                    _ = function(e) {
                        var t, n, a = 99,
                            o = function() {
                                t = null, e()
                            },
                            r = function() {
                                var e = i.now() - n;
                                e < a ? d(r, a - e) : (u || o)(o)
                            };
                        return function() {
                            n = i.now(), t || (t = d(r, a))
                        }
                    },
                    W = function() {
                        var o, c, u, m, v, E, W, L, B, F, R, S, k, O, P, T, $ = /^img$/i,
                            D = /^iframe$/i,
                            H = "onscroll" in e && !/glebot/.test(navigator.userAgent),
                            I = 0,
                            q = 0,
                            j = 0,
                            G = -1,
                            J = function(e) {
                                j--, e && e.target && p(e.target, J), (!e || j < 0 || !e.target) && (j = 0)
                            },
                            K = function(e, n) {
                                var i, o = e,
                                    r = "hidden" == A(t.body, "visibility") || "hidden" != A(e, "visibility");
                                for (F -= n, k += n, R -= n, S += n; r && (o = o.offsetParent) && o != t.body && o != a;)(r = (A(o, "opacity") || 1) > 0) && "visible" != A(o, "overflow") && (i = o.getBoundingClientRect(), r = S > i.left && R < i.right && k > i.top - 1 && F < i.bottom + 1);
                                return r
                            },
                            Q = function() {
                                var e, i, r, l, d, f, m, g, h;
                                if ((v = n.loadMode) && j < 8 && (e = o.length)) {
                                    i = 0, G++, null == P && ("expand" in n || (n.expand = a.clientHeight > 500 && a.clientWidth > 500 ? 500 : 370), O = n.expand, P = O * n.expFactor), q < P && j < 1 && G > 2 && v > 2 && !t.hidden ? (q = P, G = 0) : q = v > 1 && G > 1 && j < 6 ? O : I;
                                    for (; i < e; i++)
                                        if (o[i] && !o[i]._lazyRace)
                                            if (H)
                                                if ((g = o[i][s]("data-expand")) && (f = 1 * g) || (f = q), h !== f && (L = innerWidth + f * T, B = innerHeight + f, m = -1 * f, h = f), r = o[i].getBoundingClientRect(), (k = r.bottom) >= m && (F = r.top) <= B && (S = r.right) >= m * T && (R = r.left) <= L && (k || S || R || F) && (u && j < 3 && !g && (v < 3 || G < 4) || K(o[i], f))) {
                                                    if (ae(o[i]), d = !0, j > 9) break
                                                } else !d && u && !l && j < 4 && G < 4 && v > 2 && (c[0] || n.preloadAfterLoad) && (c[0] || !g && (k || S || R || F || "auto" != o[i][s](n.sizesAttr))) && (l = c[0] || o[i]);
                                    else ae(o[i]);
                                    l && !d && ae(l)
                                }
                                Y()
                            },
                            U = M(Q),
                            V = function(e) {
                                z(e, n.loadedClass), y(e, n.loadingClass), y(e, n.afterLoadedClass)
                            },
                            X = function(e) {
                                z(e.target, n.afterLoadedClass), Y()
                            },
                            Y = function() {
                                if (W.length > 0)
                                    for (var e, t, a = n.animateExpand, i = 0, o = 0; o < W.length; o++) {
                                        var r = W[o],
                                            l = r[s]("data-animate");
                                        l && (a = l), e = W[o].getBoundingClientRect(), t !== a && (L = innerWidth + a * T, B = innerHeight + a, i = -1 * a, t = a), (k = e.bottom) >= i && (F = e.top) <= B && (S = e.right) >= i * T && (R = e.left) <= L && (k || S || R || F) && h(r, n.afterLoadedClass) && V(r)
                                    }
                            },
                            Z = function(e, t) {
                                try {
                                    e.contentWindow.location.replace(t)
                                } catch (n) {
                                    e.src = t
                                }
                            },
                            ee = function(e) {
                                var t, a, i = e[s](n.srcsetAttr);
                                (t = n.customMedia[e[s]("data-media") || e[s]("media")]) && e.setAttribute("media", t), i && e.setAttribute("srcset", i), t && ((a = e.parentNode).insertBefore(e.cloneNode(), e), a.removeChild(e))
                            },
                            te = w((function(e, t, a, i, o) {
                                var r, l, c, u, v, h;
                                (v = C(e, "lazybeforeunveil", t)).defaultPrevented || (i && (a ? z(e, n.autosizesClass) : e.setAttribute("sizes", i)), l = e[s](n.srcsetAttr), r = e[s](n.srcAttr), o && (u = (c = e.parentNode) && f.test(c.nodeName || "")), h = t.firesLoad || "src" in e && (l || r || u), v = {
                                    target: e
                                }, h && (p(e, J, !0), clearTimeout(m), m = d(J, 2500), z(e, n.loadingClass), p(e, X, !0)), u && g.call(c.getElementsByTagName("source"), ee), l ? e.setAttribute("srcset", l) : r && !u && (D.test(e.nodeName) ? Z(e, r) : e.src = r), (l || u) && b(e, {
                                    src: r
                                })), e._lazyRace && delete e._lazyRace, y(e, n.lazyClass), N((function() {
                                    h && !ne(e) || (h ? J(v) : j--)
                                }), !0)
                            }));

                        function ne(e) {
                            return !!e.complete && (void 0 === e.naturalWidth || 0 !== e.naturalWidth)
                        }
                        var ae = function(e) {
                                var t, a = $.test(e.nodeName),
                                    i = a && (e[s](n.sizesAttr) || e[s]("sizes")),
                                    o = "auto" == i;
                                (!o && u || !a || !e.src && !e.srcset || e.complete || h(e, n.errorClass)) && (t = C(e, "lazyunveilread").detail, o && x.updateElem(e, !0, e.offsetWidth), e._lazyRace = !0, j++, te(e, t, o, i, a))
                            },
                            ie = function() {
                                if (!u)
                                    if (i.now() - E < 999) d(ie, 999);
                                    else {
                                        var e = _((function() {
                                            n.loadMode = 3, U()
                                        }));
                                        u = !0, n.loadMode = 3, U(), l("scroll", (function() {
                                            3 == n.loadMode && (n.loadMode = 2), e()
                                        }), !0)
                                    }
                            };
                        return {
                            _: function() {
                                E = i.now(), o = t.getElementsByClassName(n.lazyClass), W = t.getElementsByClassName(n.afterLoadedClass), c = t.getElementsByClassName(n.lazyClass + " " + n.preloadClass), T = n.hFac, l("scroll", U, !0), l("resize", U, !0), e.MutationObserver ? new MutationObserver(U).observe(a, {
                                    childList: !0,
                                    subtree: !0,
                                    attributes: !0
                                }) : (a[r]("DOMNodeInserted", U, !0), a[r]("DOMAttrModified", U, !0), setInterval(U, 999)), l("hashchange", U, !0), ["focus", "mouseover", "click", "load", "transitionend", "animationend", "webkitAnimationEnd"].forEach((function(e) {
                                    t[r](e, U, !0)
                                })), /d$|^c/.test(t.readyState) ? ie() : (l("load", ie), t[r]("DOMContentLoaded", U), d(ie, 2e4)), o.length ? (Q(), N._lsFlush()) : U()
                            },
                            checkElems: U,
                            unveil: ae
                        }
                    }(),
                    x = (F = w((function(e, t, n, a) {
                        var i, o, r;
                        if (e._lazysizesWidth = a, a += "px", e.setAttribute("sizes", a), f.test(t.nodeName || ""))
                            for (o = 0, r = (i = t.getElementsByTagName("source")).length; o < r; o++) i[o].setAttribute("sizes", a);
                        n.detail.dataAttr || b(e, n.detail)
                    })), R = function(e, t, n) {
                        var a, i = e.parentNode;
                        i && (n = E(e, i, n), (a = C(e, "lazybeforesizes", {
                            width: n,
                            dataAttr: !!t
                        })).defaultPrevented || (n = a.detail.width) && n !== e._lazysizesWidth && F(e, i, a, n))
                    }, S = _((function() {
                        var e, t = B.length;
                        if (t)
                            for (e = 0; e < t; e++) R(B[e])
                    })), {
                        _: function() {
                            B = t.getElementsByClassName(n.autosizesClass), l("resize", S)
                        },
                        checkElems: S,
                        updateElem: R
                    }),
                    L = function() {
                        L.i || (L.i = !0, x._(), W._())
                    };
                var B, F, R, S;
                var k, O, P, T, $, D;
                return function() {
                    var t, a = {
                        lazyClass: "lazyload",
                        loadedClass: "lazyloaded",
                        loadingClass: "lazyloading",
                        afterLoadedClass: "afterloading",
                        preloadClass: "lazypreload",
                        errorClass: "lazyerror",
                        autosizesClass: "lazyautosizes",
                        srcAttr: "data-src",
                        srcsetAttr: "data-srcset",
                        sizesAttr: "data-sizes",
                        minSize: 40,
                        customMedia: {},
                        init: !0,
                        expFactor: 1.5,
                        hFac: .8,
                        loadMode: 2,
                        animateExpand: 0
                    };
                    for (t in n = e.lazySizesConfig || e.lazysizesConfig || {}, a) t in n || (n[t] = a[t]);
                    e.lazySizesConfig = n, d((function() {
                        n.init && L()
                    }))
                }(), {
                    cfg: n,
                    autoSizer: x,
                    loader: W,
                    init: L,
                    uP: b,
                    aC: z,
                    rC: y,
                    hC: h,
                    fire: C,
                    gW: E,
                    rAF: N
                }
            }(e, e.document);
            e.lazySizes = n, "object" == typeof module && module.exports && (module.exports = n)
        }(window);
    </script>